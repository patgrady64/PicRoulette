--[[ 
Zelda Transition Timer v1.0

(Tested in FCEUX 2.2.3 with The Legend of Zelda (U) (PRG0))


====Instructions====
Using FCEUX, load your Legend of Zelda ROM.
Select "File -> Lua -> New Lua Script Window ..."
In the Lua script window, select "Browse...", load this script file, and select Run.


====Description====
This script displays the number of frames detected in each transition (period between gameplay frames).

]]


local last_frame = 0;

local recent_timer = 0;
local recent_frames = 0;

function HandleDrawing()
    if (emu.paused() == false) then
        local current_mode = memory.readbyte(0x12);
        local current_task = memory.readbyte(0x11);
        if (not (current_mode == 0x05 or
                 current_mode == 0x09 or
                 current_mode == 0x0b or
                 current_mode == 0x0c or
                 current_mode == 0x00 or
                 current_mode == 0x01) or
            current_task ~= 0x01) then
            if (recent_timer == 89) then
                recent_frames = recent_frames + 1;
            else
                recent_frames = 1;
            end;
            recent_timer = 90;
        end;

        if (recent_timer > 0) then
            recent_timer = recent_timer - 1;
            gui.drawtext(56, 8, recent_frames, "#ff8040");
        else
            recent_frames = 0;
        end;
    end;
end;

gui.register(HandleDrawing);