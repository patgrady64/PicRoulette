--[[ 
Zelda Background Visualizer v1.1

(Tested in FCEUX 2.2.3 with The Legend of Zelda (U) (PRG0))


====Instructions====
Using FCEUX, load your Legend of Zelda ROM.
Select "File -> Lua -> New Lua Script Window ..."
In the Lua script window, select "Browse...", load this script file, and select Run.


====Description====
This script visualizes background collision information for The Legend of Zelda as colored tiles. Background collision
works on tile granularity and is performed when objects are on movement grid intersections. Objects are considered to
be two tiles wide and one tile tall. For horizontal movement, one tile next to the object is sampled to decide if the
path to the next grid intersection is clear. For vertical movement, two tiles are checked and the tile with the larger
ID is kept as the representative sample. The sample tile's ID is then compared against a solid tiles index and
determined to be nonsolid if less than that index, and solid otherwise. Picking the tile with the higher ID allows for
vertical movement to pick the solid tile if one of them is nonsolid.

On the overworld, the sampled tile is also checked against a table of exception tiles. These are tiles that should be
solid because they have tile IDs at least as large as the solid tiles index, but are treated as nonsolid. If the
sampled tile is found in this list, the path to the next grid intersection is assumed to be clear.

To check for collision with entrances, the game does an extra collision when Link is block-aligned rather than simply
tile-aligned. If the sampled tile matches the specific entrance tile IDs, the entrance transition is started. Deploying
the stepladder also uses an additional collision where applicable when tile-aligned. If the sampled tile is within a
range of IDs, the stepladder is spawned.

Solid tiles are displayed in red, exception tiles in blue, and entrance tiles in greys. Water tiles are indicated with
an additional X marking, and staircase tiles with horizontal bars. Tiles being collided with by objects are marked in
green for standard collisions and white for entrance-tile collision. Object collision indicators are opaque when the
collision is actually tested and become translucent afterward until the same object collides again, allowing the
collisions to be easily seen. When a collision event checks two tiles, the tile with the lower ID, which will be
ignored, is displayed in a darker green.

Note that HUD visualization can be disabled by setting draw_hud_properties to false.


====FAQ====
Q: What versions of Zelda does this work on?
A: This was created for the US PRG0 version and should also work without issue on PRG1. It's likely that this won't
work on other versions of the game because it sets a breakpoint at a specific location in the collision handler, so if
the code has been shifted at all by other changes earlier in bank 7, that breakpoint may not work correctly, causing
the object collision indicators to display in the wrong locations. For example, indicators don't work properly in the
1993 Japanese cartridge release, but this can be fixed by setting the breakpoint (at the end of this file) from 0xEE62
to 0xEE78. Hacks with minimal code changes, such as Randomizer, will probably work fine.


====Observations====
- Overworld exception table:
The overworld exception table is a hack for making finer-grained collision for things like large trees and angled rock
walls, but it causes inconsistent collision properties for the neighboring tiles. Objects walking vertically pick the
tile with the larger ID because it's normally guaranteed to be the solid one, which will give a correct result for
whether the object can take that path. However, if a solid tile is next to an exception tile with a higher ID, it will
be ignored in favor of the nonsolid exception tile, erroneously indicating the path is clear. This manifests as tiles
that are solid when approached horizontally, but nonsolid when approached vertically.

- Entrance collision:
Entrance collision is done only when block aligned (16x16 pixel) rather than every tile. This is why Link is able to
walk over a staircase entrance while misaligned without going in. The entrance to level 6, however, is double-wide and
does allow Link to enter misaligned. This is because of a specific check that is done for that screen that causes the
collision to be done when 8x16 aligned, instead.

- Screen edges:
Due to incorrect thresholds used in code to prevent collision from trying to access tiles off the edge of the screen,
Link can't collide with tiles along the left or bottom edges of the screen when walking toward them. Instead, the fetch
will be from the previous column or row. This does not apply when objects are walking parallel to the edge. Link also
can't collide with the top row of tiles at all under normal circumstances because the scroll trigger for the edge of
the screen is reached before he needs to collide with those tiles.

The threshold behavior in general is what is responsible for Link getting stuck when using the screen-scroll bug to go
left-to-right into a solid wall. The fetched tile would wrap back around to the left side when trying to walk back from
the wall, but the game clamps it to the rightmost column of the screen, causing Link to collide with solids in both
directions.

- HUD collision:
If Link clips into the HUD, he will collide with a copy of the upper portion of the current screen, shifted left by
one tile. The tilemap for the current screen is made up of 32 columns that are 22 tiles tall, stored contiguously in
memory. These columns start where the HUD ends. Because of this, when Link is in the HUD, he is actually at the end of
the column he's standing in. Because the columns only contain enough data for the playable portion of the screen rather
than the entire screen, indexing that far into the column overflows into the next column. This is why the tiles are
shifted to the left by one: the tiles at the end of the column are literally the same ones from the start of the next.

There are 10 tiles total in the HUD region. 8 of them are visible with the script, but the remaining 2, which mirror
the top of the playfield, cannot be seen because they lie outside of the NES' screen output. This is because the screen
is only 240 pixels tall rather than 256. Object positions use a byte and can use the entire 0-255 value range, so those
first 2 tiles are invisible.

The HUD is made up of data from the next column, but the last column is not followed by any more tile data, so it uses
the data that follows the tilemap in RAM. This happens to be a PPU sequence for writing palette data to PPU memory.
PPU addresses and palette colors are all lower than the overworld and dungeon solid tiles indices, as is the size of
the payload, so the bytes that are interpreted here as tiles will always be nonsolid. This prevents Link from getting
stuck when performing the screen-scroll bug left-to-right in the HUD.

Because the tiles are shifted one to the left, it is common for the HUD to contain a wall on the left that is only a
single tile wide. Because of the threshold behavior described in the "Screen edges" observation, Link is able to walk
through these walls leftward as though they're not there.

Because entrance collision is only done when block-aligned instead of tile-aligned, colliding with these in the HUD
can be difficult and may require clips to get Link's entrance-collision point to sample the entrance tile.

- Zora spawning:
The zora spawns at a random location on the screen, tests whether it's water, and tries again if it's not. The less
water there is on the screen, the longer it will take for the zora to find a valid spawn point. The script will show
all locations tried by the zora on the current frame.

- Performance:
Depending on where Link stands and on what screen, collision may be sampled on every single frame. The entrance-tile
collision is done every single frame while Link is block-aligned and uses 1% of the frame budget on the overworld and
0.5% in dungeons. Stepladder collision is done every frame while Link is tile-aligned on some overworld screens and all
dungeon screens, and uses up to 1.4% of the frame budget on the overworld and 0.8% in dungeons. Multidirectional input
will also cause an additional collision check to be performed, but only once when tile-aligned rather than every frame
unless Link is running in place against a solid.

Exceeding the frame budget causes one lag frame each time.


====Release Notes====
v1.1:
- Fixed a bug that prevented stepladder markers from showing up in dungeons other than level 1.

v1.0:
Initial release.

]]


--[[ Controls whether the HUD collision will be drawn or not. This is primarily relevant for speedrunners to route
     through the HUD and might be best turned off for other use cases, especially for hacks that fix the screen-scroll
     bug. Set to false to disable.
  ]]
local draw_hud_properties = true;

local kTilemap = 0x6530;
local kExceptions = { 0x8D, 0x91, 0x9C, 0xAC, 0xAD, 0xCC, 0xD2, 0xD5, 0xDF };

local fresh = {};
local stale = {};

local kNumEntries = 13;

function CaptureCollision()
    local object_index = memory.getregister("x");
    local tile_row_index = memory.getregister("y");
    local face_direction = memory.readbyte(0x0f);
    local tilemap_column = memory.readword(0);

    -- The first index is a special slot for displaying the entrance-tile collision.
    local i = object_index + 2;
    if (object_index == 0 and face_direction == 0) then
        i = 1;
    end;

    local x = math.floor((tilemap_column - kTilemap) / 22) * 8;
    local y = ((tile_row_index * 8) + 0x40) % 0x100;
    local tile1 = {x, y, true};
    local tile2 = nil;

    -- If the collision is vertical, two tiles are being checked, so mark both.
    if (bit.band(face_direction, 0xc) ~= 0) then
        tile2 = {x+8, y, false};
        local tile_position = tilemap_column + tile_row_index;
        if (memory.readbyte(tile_position) <= memory.readbyte(tile_position + 22)) then
            tile1[3] = false;
            tile2[3] = true;
        end;
    end;

    -- Add the collision to the list of fresh collisions for this object.
    if (fresh[i] == nil) then
        fresh[i] = {};
    end;
    table.insert(fresh[i], tile1);
    if (tile2 ~= nil) then table.insert(fresh[i], tile2) end;
end;


function ContainsElement(table, value)
    for i=1,#table do
        if (table[i] == value) then
            return true;
        end;
    end;

    return false;
end;


function DrawBackgroundTile(tile, x, y, level, mode, solid)
    -- Exception tiles.
    if (level == 0 and ContainsElement(kExceptions, tile) == true) then
        gui.drawbox(x, y, x + 7, y + 7, "#0000ff40", "#0000ff80");

    -- Solid tiles.
    elseif (tile >= solid) then
        gui.drawbox(x, y, x + 7, y + 7, "#ff000040", "#ff000080");

    -- Entrance tiles.
    elseif (mode == 5 and
            ((tile >= 0x70 and tile < 0x74) or
             (level == 0 and (tile == 0x24 or tile == 0x88)))) then
        gui.drawbox(x, y, x + 7, y + 7, "#00000040", "#ffffff80");
    end;

    -- Water tiles. Mark these separately.
    if ((level == 0 and (tile >= 0x8d and tile < 0x99)) or
        (level ~= 0 and tile == 0xF4)) then
        gui.drawline(x, y,     x + 7, y + 7, "#ffffff80");
        gui.drawline(x, y + 7, x + 7, y,     "#ffffff80");
    end;

    -- Staircase tiles. Mark these separately.
    if (level == 0 and (tile == 0x74 or tile == 0x75)) then
        gui.drawline(x, y+1, x+7, y+1, "#ffffffc0");
        gui.drawline(x, y+3, x+7, y+3, "#ffffffc0");
        gui.drawline(x, y+5, x+7, y+5, "#ffffffc0");
        gui.drawline(x, y+7, x+7, y+7, "#ffffffc0");
    end;
end;


-- TODO: Add support for the hidden path on screen 0x1F if inspiration strikes on how to visualize it cleanly.
function HandleDrawing()
    local mode = memory.readbyte(0x12);
    local task = memory.readbyte(0x11);
    local start_menu_status = memory.readbyte(0xe1);

    -- Don't draw the collision information while paused.
    if (start_menu_status ~= 0) then return end;

    -- Gameplay modes.
    if (task ~= 0 and
        (mode == 5 or (mode >= 0x9 and mode <= 0xc))) then

        local solid = memory.readbyte(0x34a);
        local level = memory.readbyte(0x10);

        -- Draw HUD solidity.
        if (draw_hud_properties == true) then
            for i=0,31 do
                local column = memory.readword(0xe400 + (i*2));
                for j=24,31 do
                    local tile = memory.readbyte(column + j);
                    local x = i * 8;
                    local y = (j-24) * 8;

                    DrawBackgroundTile(tile, x, y, level, mode, solid);
                end;
            end;
        end;

        -- Draw playfield solidity.
        for i=0,703 do
            local tile = memory.readbyte(kTilemap + i);
            local x = math.floor((i/22)) * 8;
            local y = 0x40 + math.floor((i%22) * 8);

            DrawBackgroundTile(tile, x, y, level, mode, solid);
        end;

        -- Draw background collision for each object.
        for obj_index=-1,11 do
            local i = obj_index + 2;
            local fill_color;
            local outline_color;

            -- Draw the new collisions for this object.
            if (fresh[i] ~= nil) then
                for j=1,#fresh[i] do
                    local x = fresh[i][j][1];
                    local y = fresh[i][j][2];

                    -- Standard collision.
                    if (i ~= 1) then
                        local rep = fresh[i][j][3];

                        if (rep == true) then
                            outline_color = "#00ff00";
                            fill_color = "#00ff00";
                        else
                            outline_color = "#00c080";
                            fill_color = "#00c080";
                        end;

                    -- Entrance-tile collision.
                    else
                        fill_color = "#ffffff";
                        outline_color = "#000000";
                    end;

                    gui.drawbox(x, y, x+7, y+7, fill_color, outline_color);
                end;

            -- If there aren't any new collisions, draw the old ones.
            elseif (stale[i] ~= nil) then
                for j=1,#stale[i] do
                    local x = stale[i][j][1];
                    local y = stale[i][j][2];

                    -- Standard collision.
                    if (i ~= 1) then
                        local rep = stale[i][j][3];

                        if (rep == true) then
                            outline_color = "#00ff0080";
                            fill_color = "#00ff0040";
                        else
                            outline_color = "#00c08080";
                            fill_color = "#00c08040";
                        end;

                    -- Entrance-tile collision.
                    else
                        fill_color = "#ffffff40";
                        outline_color = "#00000080";
                    end;

                    gui.drawbox(x, y, x+7, y+7, fill_color, outline_color);
                end;
            end;
        end;

        -- Move all new fresh entries into the stale table.
        for i=1,kNumEntries do
            -- If this isn't related to Link and the object doesn't exist, remove its collision.
            if (i > 2 and memory.readbyte(0x350 - 3 + i) == 0) then
                stale[i] = nil;
                fresh[i] = nil;

            -- If there's a fresh entry, make it stale.
            elseif (fresh[i] ~= nil) then
                stale[i] = fresh[i];
                fresh[i] = nil;
            end;
        end;

    -- Non-gameplay modes.
    else
        -- Clear the collision information, as it won't be relevant anymore when we return to a gameplay mode.
        stale = {};
        fresh = {};
    end;
end;


--[[ Set an execute breakpoint in the collision detection function so we can capture all collision events. If collision
     indicators aren't working properly, this needs to be updated to point at the first STA $049E in the collision
     handler for the targeted version of Zelda. In the 1993 Japanese cartridge release, for example, this should be
     0xEE78.
  ]]
memory.registerexecute(0xEE62, CaptureCollision);

-- Main loop.
while (true) do
    HandleDrawing();
    emu.frameadvance();
end;