--[[ 
Zelda Lag Detector v1.0

(Tested in FCEUX 2.2.3 with The Legend of Zelda (U) (PRG0))


====Instructions====
Using FCEUX, load your Legend of Zelda ROM.
Select "File -> Lua -> New Lua Script Window ..."
In the Lua script window, select "Browse...", load this script file, and select Run.


====Description====
This script displays the total number of lag frames detected since the script was loaded, as well as the number of
recent lag frames. FCEUX's lag frame detector assumes that lag frames are any in which input is not polled by the game,
but Zelda will avoid polling input during some game modes, such as scrolling, so FCEUX's approach is not correct for
it. This script works by detecting any frame where the frame counter has not yet advanced.

]]


local last_frame = 0;
local total_lag = 0;

local recent_lag_timer = 0;
local recent_lag = 0;

function HandleDrawing()
    if (emu.paused() == false) then
        local current_frame = memory.readbyte(0x15);
        if (current_frame == last_frame) then
            emu.setlagflag(true);
            total_lag = total_lag + 1;
            recent_lag = recent_lag + 1;
            recent_lag_timer = 90;
        else
            emu.setlagflag(false);
        end;

        if (recent_lag_timer > 0) then
            recent_lag_timer = recent_lag_timer - 1;
            gui.drawtext(56, 8, recent_lag, "#ff8040");
        else
            recent_lag = 0;
        end;

        last_frame = current_frame;

        gui.drawtext(8, 8, total_lag);
    end;
end;

gui.register(HandleDrawing);