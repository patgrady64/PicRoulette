--[[
Zelda Object Targeting v1.0

(Tested in FCEUX 2.2.3 with The Legend of Zelda (U) (PRG0))


====Instructions====
Using FCEUX, load your Legend of Zelda ROM.
Select "File -> Lua -> New Lua Script Window ..."
In the Lua script window, select "Browse...", load this script file, and select Run.


====Description====
This script displays the current position that enemies target, as well as detailed information about turning behavior
for certain types of enemies. The current target alternates at random between Link and his bitwise-opposite position on
the screen, referred to as anti-Link. When the target is Link, it follows him as he moves. When it is anti-Link, it
remains stationary until the next swap. When bait is placed, if the primary object (the first one to spawn on the
screen) is one of a specific set of enemies, then the target will be the bait for as long as it remains active.

Positions are indicated with a black dot surrounded by a square. The current target is surrounded by targeting
information. Two lines intersecting at the target position show the dividing line between being on one side of the
target and the other, which is important for a number of enemies. A plus-sized region extending to the edges of the
screen indicates the aggressive turning area, within which (inclusive of the borders) aggressive enemies have a chance
of turning directly toward the target. A square-shaped region indicates the area in which enemies with proximity
targeting will home in on the target position.

Enemies with aggressive targeting show two numbers. The top number is a frame count indicating their turn timer. When
this timer hits 0, the enemy will turn 90 degrees toward the target. This direction is indicated by a dark edge on the
position square. The bottom number is the aggression chance. When an enemy is within the aggressive turning area, this
is the chance it will turn directly toward the target. The turning direction when within this area is indicated by a
bright red line on one side of the position square.

Enemies with proximity targeting can optionally show two numbers (disabled by default). These are distances along the
X axis and the Y axis from the target. When both are less than 0x51 (that is, within the square region around the
target), the enemy will turn toward the target along the axis with the larger distance.

Targeting for rock generators is displayed as a red line at the top of one half of the screen. The generator will
always drop rocks on the half of the screen containing the target. The rocks themselves will move toward the current
target while falling. This direction is indicated with a red line on one side of the position square.

Note that other enemies do still do targeting of some sort, but are just not supported by the script at this time.


Individual visual elements can be enabled or disabled to show as much or as little information as desired. See the
"Options" section below.


====FAQ====
Q: What versions of Zelda does this work on?
A: This was created for the US PRG0 version and should also work without issue on PRG1. It's likely that this won't
work on other versions of the game because it requires some code to be in a specific location for breakpoints, so if
the code has been shifted at all by other changes earlier in bank 4, those breakpoints may not work correctly, causing
enemy turn data to not be properly collected. This can be fixed by fixing up the breakpoint addresses to match the
version of the game being used.


====Known Issues====
- If an object is cleared and another object spawns into its slot on the same frame, that object may incorrectly show
  data cached from the previous object.


====Unsupported====
These features are unsupported in this version, but may be added later. This list is not intended to be exhaustive.
- Flying enemy targeting
- Tektite targeting
- Lanmola targeting
- Pols voice targeting
- Wizzrobe targeting
- Ganon targeting
- Initial spawn direction for lynels, moblins, goriyas, vires, zols, gels, pols voice, like likes, stalfos, and gibdos.

]]


--[[ ====Options====
     These variables can be modified to control what information the script will display. Displaying too much can make
     it difficult to extract useful information, so it's a good idea to keep it to the minimum you need for your task. 

     Setting a variable to true will enable its functionality, and setting it to false will disable it.
]]

-- Information about the current target position.
local kDrawTargetingPoints = true;
local kDrawAggression = true;
local kDrawProximity = true;
local kDrawDivider = true;

-- Information about the inactive target positions.
local kDrawInactiveTargetingPoints = true;
local kDrawInactiveAggression = false;
local kDrawInactiveProximity = false;
local kDrawInactiveDivier = false;

-- Aggression text.
local kDrawTimers = true;
local kDrawChance = true;

-- Proximity text.
local kDrawProximityDeltas = false;

-- Movement grid overlay.
local kDrawGrid = false;
local kDrawGridIntersections = true;




local kHexTable = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"};

function DrawHex(x, y, value, text, background)
    gui.drawtext(x,   y, kHexTable[math.floor(value / 16) + 1], text, background);
    gui.drawtext(x+6, y, kHexTable[value % 16 + 1], text, background);
end;


function DrawGrid()
    -- Draw a dot at each grid intersection so they're more visible.
    if (kDrawGridIntersections == true) then
        for x=0,15 do
            for y=0,10 do
                gui.drawpixel(x*16, y*16 + 0x3d, "#ffffff80");
            end;
        end;
    end;

    -- Draw faint x and y gridlines.    
    if (kDrawGrid == true) then
        for i=0,15 do
            gui.drawline(i*16, 0x40, i*16, 0xdd, "#ffffff40");
        end;
        for i=0,10 do
            gui.drawline(0x00, i*16 + 0x3d, 0xf0, i*16 + 0x3d, "#ffffff40");
        end;
    end;
end;


function DrawRegions(x, y, active, point)
    if (active == false and kDrawInactiveRanges == false) then
        return;
    end;

    local aggression_fill;
    local aggression_border;

    if (active == true) then
        aggression_fill = "#0000ff40";
        aggression_border = "#0000ff";
        proximity_fill = "#00ff0040";
        proximity_border = "#00ff00";
        divider_color = "#808080";
    else
        aggression_fill = "#00000000";
        aggression_border = "#0000ff40";
        proximity_fill = "#00000000";
        proximity_border = "#00ff0040";
        divider_color = "#80808080";
    end;

    -- Proximity range.
    if ((active == true and kDrawProximity == true) or
        (active == false and kDrawInactiveProximity)) then
        gui.drawbox(x - 0x50, y - 0x50, x + 0x50, y + 0x50, proximity_fill, proximity_border);
    end;

    -- Aggression range.
    if ((active == true and kDrawAggression == true) or
        (active == false and kDrawInactiveAggression)) then
        gui.drawbox(x - 8, -1,    x + 8, 0x100, aggression_fill, aggression_border);
        gui.drawbox(-1,    y - 8, 0x100, y + 8, aggression_fill, aggression_border);
    end;

    -- Divider.
    if ((active == true and kDrawDivider == true) or
        (active == false and kDrawInactiveDivider)) then
        gui.drawline(0, y, 0xff, y, divider_color);
        gui.drawline(x, 0, x, 0xff, divider_color);
    end;

    -- Position.
    if ((active == true and kDrawTargetingPoints == true) or
        (active == false and kDrawInactiveTargetingPoints)) then
        gui.drawbox(x - 1, y - 1, x + 1, y + 1, "#000000", point);
    end;
end;


local distraction_delay = false;

function DrawTargetRegions()
    local target_x = memory.readbyte(0x61);
    local target_y = memory.readbyte(0x62);
    local link_x = memory.readbyte(0x70);
    local link_y = memory.readbyte(0x84);
    local antilink_x = bit.bxor(link_x, 0xff);
    local antilink_y = bit.bxor(link_y, 0xff);

    DrawRegions(link_x, link_y, false, "#00ff00");
    DrawRegions(antilink_x, antilink_y, false, "#ff0000");
    DrawRegions(target_x, target_y, true, "#0000ff");
end;


-- An object is active if it has ever acted aggressively, and fresh if it has done so this frame.
local aggression_active = {false, false, false, false, false, false, false, false, false, false, false};
local aggression_fresh  = {false, false, false, false, false, false, false, false, false, false, false};

local proximity_active  = {false, false, false, false, false, false, false, false, false, false, false};
 
function DrawObjectActualPositions()
    -- Dynamic objects.
    for i=1,11 do
        local id = memory.readbyte(0x34f + i);
        local x = memory.readbyte(0x70 + i);
        local y = memory.readbyte(0x84 + i); 
        local target_x = memory.readbyte(0x61);
        local target_y = memory.readbyte(0x62);

        -- Standard objects.
        if (id ~= 0 and id < 0x53) then
            -- If this object is aggressive, print relevant aggression information.
            if (aggression_active[i] == true) then
                -- Draw the turn timer and aggression chance.
                local color1 = "#ffffff";
                local color2 = "#0000ff80";

                if (aggression_fresh[i] == false) then
                    color1 = "#ffffffbf";
                    color2 = "#0000ff40";
                end;

                if (kDrawTimers == true) then
                    local timer = memory.readbyte(0x478 + i);
                    gui.drawtext(x+2, y+2, timer, color1, color2);
                end;
                if (kDrawChance == true) then
                    local chance = memory.readbyte(0x41f + i);
                    gui.drawtext(x+2, y+10, math.floor(chance/255 * 100), "#ffffff80", "#0000ff40");
                end;
            end;

            -- Draw the position of the object.
            gui.drawbox(x-1, y-1, x+1, y+1, "#000000", "#ffffff");

            -- Draw aggressive turn indicators.
            if (aggression_active[i] == true) then
                -- Aggressive turn.
                if (math.abs(target_x - x) < 9) then
                    if (target_y < y) then
                        -- Draw up
                        gui.drawline(x-2, y-2, x+2, y-2, "#ff0040");
                    else
                        -- Draw down
                        gui.drawline(x-2, y+2, x+2, y+2, "#ff0040");
                    end;
                elseif (math.abs(target_y - y) < 9) then
                    if (target_x < x) then
                        -- Draw left
                        gui.drawline(x-2, y+2, x-2, y-2, "#ff0040");
                    else
                        -- Draw right
                        gui.drawline(x+2, y+2, x+2, y-2, "#ff0040");
                    end;
                end;

                -- Timer turn.
                local face = memory.readbyte(0x98 + i);
                if (face > 0x03) then
                    if (target_x < x) then
                        -- Draw left
                        gui.drawline(x-1, y+1, x-1, y-1, "#400040");
                    else
                        -- Draw right
                        gui.drawline(x+1, y+1, x+1, y-1, "#400040");
                    end;
                else
                    if (target_y < y) then
                        -- Draw up
                        gui.drawline(x-1, y-1, x+1, y-1, "#400040");
                    else
                        -- Draw down
                        gui.drawline(x-1, y+1, x+1, y+1, "#400040");
                    end;
                end;
            end;

            if (proximity_active[i] == true) then
                local y_direction = 0x04;
                local y_delta = target_y - y;
                if (target_y < y) then
                    y_direction = 0x08;
                    y_delta = y - target_y;
                end;

                local x_direction = 0x01;
                local x_delta = target_x - x;
                if (target_x < x) then
                    x_direction = 0x02;
                    x_delta = x - target_x;
                end;

                -- Draw the deltas.
                if (kDrawProximityDeltas == true) then
                    local x_text;
                    local x_background;

                    if (x_delta < 0x51) then
                        x_text = "#ffffff"
                        x_background = "#0000ff80"
                    else
                        x_text = "#888888"
                        x_background = "#0000ff80"
                    end;

                    local y_text;
                    local y_background;

                    if (y_delta < 0x51) then
                        y_text = "#ffffff"
                        y_background = "#0000ff80"
                    else
                        y_text = "#888888"
                        y_background = "#0000ff80"
                    end;

                    DrawHex(x+2, y+2,  x_delta, x_text, x_background);
                    DrawHex(x+2, y+10, y_delta, y_text, y_background);
                end;

                -- Figure out what direction to move in.
                local direction = 0x00;
                if (y_delta < x_delta) then
                    if (x_delta < 0x51) then
                        direction = x_direction;
                    end;
                else
                    if (y_delta < 0x51) then
                        direction = y_direction;
                    end;
                end;

                -- Draw the direction indicator.
                if (direction == 0x01) then
                    -- Draw right
                    gui.drawline(x+2, y+2, x+2, y-2, "#ff0040");
                elseif (direction == 0x02) then
                    -- Draw left
                    gui.drawline(x-2, y+2, x-2, y-2, "#ff0040");
                elseif (direction == 0x04) then
                    -- Draw down
                    gui.drawline(x-2, y+2, x+2, y+2, "#ff0040");
                elseif (direction == 0x08) then
                    -- Draw up
                    gui.drawline(x-2, y-2, x+2, y-2, "#ff0040");
                end;
            end;

            -- Rock generator.
            if (id == 0x1f) then
                if (target_x < 0x80) then
                    gui.drawline(0, 0x40, 0x7f, 0x40, "#ff0000");
                else
                    gui.drawline(0x80, 0x40, 0xff, 0x40, "#ff0000");
                end;
            end;

            -- Rock. Tektite.
            --if (id == 0x0d or id == 0x0e or id == 0x20) then
            if (id == 0x20) then
                if (target_x < x) then
                    -- Draw left
                    gui.drawline(x-2, y+2, x-2, y-2, "#ff0040");
                else
                    -- Draw right
                    gui.drawline(x+2, y+2, x+2, y-2, "#ff0040");
                end;
            end;
        end;
    end;
end;


function CacheAggressionData()
    local mode = memory.readbyte(0x12);
    local task = memory.readbyte(0x11);
    local start_menu_status = memory.readbyte(0xe1);

    if (start_menu_status == 0 and
        task ~= 0 and
        (mode == 5 or (mode >= 0x9 and mode <= 0xc))) then
        -- Cache this object's aggression data.
        local index = memory.getregister("x");
        local x = memory.readbyte(0x70 + index);
        local y = memory.readbyte(0x84 + index);

        aggression_active[index] = true;
        aggression_fresh[index] = true;
    end;
end;


function CacheProximityData()
    local mode = memory.readbyte(0x12);
    local task = memory.readbyte(0x11);
    local start_menu_status = memory.readbyte(0xe1);

    if (start_menu_status == 0 and
        task ~= 0 and
        (mode == 5 or (mode >= 0x9 and mode <= 0xc))) then
        -- Cache this object's aggression data.
        local index = memory.getregister("x");

        proximity_active[index] = true;
    end;
end;


function HandleDrawing()
    local mode = memory.readbyte(0x12);
    local task = memory.readbyte(0x11);
    local start_menu_status = memory.readbyte(0xe1);

    if (task ~= 0 and
        (mode == 5 or (mode >= 0x9 and mode <= 0xc))) then
        if (start_menu_status == 0) then
            DrawTargetRegions();
            DrawGrid();
            DrawObjectActualPositions();

            --[[ If an enemy is deleted, make it unlikely its cache will stick to anything that might spawn into its slot.
                 This isn't guaranteed because the slot could fill again on the same frame. ]]
            for i=1,11 do
                local id = memory.readbyte(0x34f + i);
                local spawn = memory.readbyte(0x405 + i);
                if (id == 0x00 or id > 0x4a or bit.band(spawn, 0x10) ~= 0x00) then
                    aggression_active[i] = false;
                    proximity_active[i] = false;
                end;
            end;
        end;
    else
        -- We're not in a gameplay frame, so clear the object aggression cache.
        for i=1,11 do
            aggression_active[i] = false;
            proximity_active[i] = false;
        end;
    end;

    -- Mark all objects stale each frame so we can see when objects are calling the aggression function.
    for i=1,11 do
        aggression_fresh[i] = false;
    end;
end;


memory.registerexecute(0x8094, CacheAggressionData);
memory.registerexecute(0x8131, CacheProximityData);

-- Main loop.
while (true) do
    HandleDrawing();
    emu.frameadvance();
end;