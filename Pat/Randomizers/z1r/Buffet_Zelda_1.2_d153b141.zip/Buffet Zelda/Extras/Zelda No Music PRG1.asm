; Removes all music from The Legend of Zelda (PRG1) without changing the
; game's performance in any way.
;
; This WILL NOT work with the PRG0 or J-cart ROMs; many of the PRG1 sound bank
; addresses are slightly different due to a small data optimization and a DPCM
; code change.
;
; To assemble:
; snarfblasm.exe zelda_no_music_prg1.asm
; This produces zelda_no_music_prg1.ips, to be applied to the target ROM.


.PATCH   $10  ; FREE
.BASE  $8000

  ; The branch targets in these functions don't exactly mimic the original
  ; branches, but they don't have to; they just need to branch to an RTS
  ; without crossing a page boundary.

  ; 00:9BFF:8C 01 40  STY SQ1_SWEEP
  ; 00:9C02:8E 00 40  STX SQ1_VOL
  ; 00:9C05:60        RTS

  ; 00:9C1D:8E 04 40  STX SQ2_VOL
  ; 00:9C20:8C 05 40  STY SQ2_SWEEP
  ; 00:9C23:60        RTS

  PulseNoSound:
    NOP
    NOP
    NOP
    NOP
    RTS


  ; 00:9C09:A8        TAY
  ; 00:9C0A:B9 01 9F  LDA $9F01,Y
  ; 00:9C0D:F0 0D     BEQ $9C1C
  ; 00:9C0F:85 6A     STA $6A
  ; 00:9C11:8D 02 40  STA SQ1_LO
  ; 00:9C14:B9 00 9F  LDA $9F00,Y
  ; 00:9C17:09 08     ORA #$08
  ; 00:9C19:8D 03 40  STA SQ1_HI
  ; 00:9C1C:60        RTS

  Pulse1TimerNoSound:
    TAY
    LDA $9F01,Y
    BEQ Pulse1TimerNoSound_BranchDestination
   Pulse1TimerNoSound_BranchSource:

    STA <$6A
    LDA $8000
    LDA $9F00,Y
    ORA #$08
    NOP
    NOP

   Pulse1TimerNoSound_BranchDestination:
    RTS

  .IF >Pulse1TimerNoSound_BranchSource != >Pulse1TimerNoSound_BranchDestination
  .ERROR Branch target does not reside on same page; cycle count will be 1 too high.
  .ENDIF


  ; 00:9C27:A8        TAY
  ; 00:9C28:B9 01 9F  LDA $9F01,Y
  ; 00:9C2B:F0 EF     BEQ $9C1C
  ; 00:9C2D:85 6B     STA $6B
  ; 00:9C2F:8D 06 40  STA SQ2_LO
  ; 00:9C32:B9 00 9F  LDA $9F00,Y
  ; 00:9C35:09 08     ORA #$08
  ; 00:9C37:8D 07 40  STA SQ2_HI
  ; 00:9C3A:60        RTS

  Pulse2TimerNoSound:
    TAY
    LDA $9F01,Y

    BEQ Pulse2TimerNoSound_BranchDestination
   Pulse2TimerNoSound_BranchSource:

    STA <$6B
    LDA $8000
    LDA $9F00,Y
    ORA #$08
    NOP
    NOP
   
   Pulse2TimerNoSound_BranchDestination:
    RTS

  .IF >Pulse2TimerNoSound_BranchSource != >Pulse2TimerNoSound_BranchDestination
  .ERROR Branch target does not reside on same page; cycle count will be 1 too high.
  .ENDIF


  ; 00:9C3B:A8        TAY
  ; 00:9C3C:B9 01 9F  LDA $9F01,Y
  ; 00:9C3F:F0 DB     BEQ $9C1C
  ; 00:9C41:8D F0 05  STA $05F0
  ; 00:9C44:8D 0A 40  STA TRI_LO
  ; 00:9C47:B9 00 9F  LDA $9F00,Y
  ; 00:9C4A:09 08     ORA #$08
  ; 00:9C4C:8D 0B 40  STA TRI_HI
  ; 00:9C4F:60        RTS

  TriangleTimerNoSound:
    TAY
    LDA $9F01,Y
    BEQ TriangleTimerNoSound_BranchDestination
   TriangleTimerNoSound_BranchSource:

    STA $05F0
    LDA $8000
    LDA $9F00,Y
    ORA #$08
    NOP
    NOP

   TriangleTimerNoSound_BranchDestination:
    RTS

  .IF >TriangleTimerNoSound_BranchSource != >TriangleTimerNoSound_BranchDestination
  .ERROR Branch target does not reside on same page; cycle count will be 1 too high.
  .ENDIF


  .IF $ > $8D60
  .ERROR Exceeded free region.
  .ENDIF



.PATCH $1D76  ; CODE
.BASE  $9D66

  ; 00:9D66:20 27 9C  JSR $9C27

    JSR Pulse2TimerNoSound


  .IF $ != $9D69
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1D81  ; CODE
.BASE  $9D71

  ; 00:9D71:20 1D 9C  JSR $9C1D

    JSR PulseNoSound


  .IF $ != $9D74
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1DA2  ; CODE
.BASE  $9D92

  ; 00:9D92:8D 04 40  STA SQ2_VOL
  ; 00:9D95:A2 7F     LDX #$7F
  ; 00:9D97:8E 05 40  STX SQ2_SWEEP
  ; 00:9D9A:AD 09 06  LDA $0609

    LDA $8000
    LDX #$7F
    LDA $8000


  .IF $ != $9D9A
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1DB7  ; CODE
.BASE  $9DA7

  ; 00:9DA7:8E 06 40  STX SQ2_LO
  ; 00:9DAA:AC 0B 06  LDY $060B

    LDY $8000


  .IF $ != $9DAA
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1DE1  ; CODE
.BASE  $9DD1

  ; 00:9DD1:20 09 9C  JSR $9C09

    JSR Pulse1TimerNoSound


  .IF $ != $9DD4
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1DEC  ; CODE
.BASE  $9DDC

  ; 00:9DDC:20 FF 9B  JSR $9BFF

    JSR PulseNoSound


  .IF $ != $9DDF
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1E0D  ; CODE
.BASE  $9DFD

  ; 00:9DFD:8D 00 40  STA SQ1_VOL
  ; 00:9E00:AD 09 06  LDA $0609

    LDA $8000


  .IF $ != $9E00
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1E1D  ; CODE
.BASE  $9E0D

  ; 00:9E0D:8E 02 40  STX SQ1_LO
  ; 00:9E10:A9 7F     LDA #$7F
  ; 00:9E12:8D 01 40  STA SQ1_SWEEP
  ; 00:9E15:AD 0C 06  LDA $060C

    LDA $8000
    LDA #$7F
    LDA $8000


  .IF $ != $9E15
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1E69  ; CODE
.BASE  $9E59

  ; 00:9E59:8D 08 40  STA TRI_LINEAR
  ; 00:9E5C:AC 0C 06  LDY $060C

    LDY $8000


  .IF $ != $9E5C
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1E76  ; CODE
.BASE  $9E66

  ; 00:9E66:20 3B 9C  JSR $9C3B

    JSR TriangleTimerNoSound


  .IF $ != $9E69
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1E90  ; CODE
.BASE  $9E80

  ; 00:9E80:8E 0A 40  STX TRI_LO
  ; 00:9E83:AD F1 05  LDA $05F1

    LDA $8000


  .IF $ != $9E83
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1E9E  ; CODE
.BASE  $9E8E

  ; 00:9E8E:8D 08 40  STA TRI_LINEAR
  ; 00:9E91:AD 09 06  LDA $0609

    LDA $8000


  .IF $ != $9E91
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1ED0  ; CODE
.BASE  $9EC0

  ; 00:9EC0:8D 0C 40  STA NOISE_VOL
  ; 00:9EC3:B9 D4 9E  LDA $9ED4,Y
  ; 00:9EC6:8D 0E 40  STA NOISE_LO
  ; 00:9EC9:B9 D8 9E  LDA $9ED8,Y
  ; 00:9ECC:8D 0F 40  STA NOISE_HI
  ; 00:9ECF:60        RTS

    LDA $8000
    LDA $9ED4,Y
    LDA $8000
    LDA $9ED8,Y

    ; Because we want to be absolutely sure we don't change the behavior of
    ; anything after the RTS, we use 2 NOPs here for the same cycle count
    ; instead of a 4 cycle instruction that would change registers or flags.
    ; The old RTS is left in place for anything that may branch to it.
    NOP  ; 2 cycles.
    NOP  ; 2 cycles.
    RTS


  .IF $ != $9ECF
  .ERROR Patch is wrong length.
  .ENDIF