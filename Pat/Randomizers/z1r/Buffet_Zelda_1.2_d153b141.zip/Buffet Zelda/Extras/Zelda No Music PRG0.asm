; Removes all music from The Legend of Zelda (PRG0) without changing the
; game's performance in any way.
;
; This WILL NOT work with the PRG1 ROM; many of the PRG1 sound bank addresses
; are slightly different due to a small data optimization and a DPCM code
; change. This WILL work with the Japanese cartridge release, which reverts
; these changes.
;
; To assemble:
; snarfblasm.exe zelda_no_music.asm
; This produces zelda_no_music.ips, to be applied to the target ROM.


.PATCH   $10  ; FREE
.BASE  $8000

  ; The branch targets in these functions don't exactly mimic the original
  ; branches, but they don't have to; they just need to branch to an RTS
  ; without crossing a page boundary.

  ; Bank0_9C03: 8C 0140       STY PULSE1_SWEEP
  ; Bank0_9C06: 8E 0040       STX PULSE1_CONTROL
  ; Bank0_9C09: 60            RTS

  ; Bank0_9C21: 8E 0440       STX PULSE2_CONTROL
  ; Bank0_9C24: 8C 0540       STY PULSE2_SWEEP
  ; Bank0_9C27: 60            RTS

  PulseNoSound:
    NOP
    NOP
    NOP
    NOP
    RTS


  ; Bank0_9C0D: A8            TAY
  ; Bank0_9C0E: B9 019F       LDA $9F01,Y
  ; Bank0_9C11: F0 0D         BEQ $9C20
  ; Bank0_9C13: 85 6A         STA <$6A
  ; Bank0_9C15: 8D 0240       STA PULSE1_TIMER_LOW
  ; Bank0_9C18: B9 009F       LDA $9F00,Y
  ; Bank0_9C1B: 09 08         ORA #$08
  ; Bank0_9C1D: 8D 0340       STA PULSE1_TIMER_HIGH
  ; Bank0_9C20: 60            RTS

  Pulse1TimerNoSound:
    TAY
    LDA $9F01,Y
    BEQ Pulse1TimerNoSound_BranchDestination
   Pulse1TimerNoSound_BranchSource:

    STA <$6A
    LDA $8000
    LDA $9F00,Y
    ORA #$08
    NOP
    NOP

   Pulse1TimerNoSound_BranchDestination:
    RTS

  .IF >Pulse1TimerNoSound_BranchSource != >Pulse1TimerNoSound_BranchDestination
  .ERROR Branch target does not reside on same page; cycle count will be 1 too high.
  .ENDIF


  ; Bank0_9C2B: A8            TAY
  ; Bank0_9C2C: B9 019F       LDA $9F01,Y
  ; Bank0_9C2F: F0 EF         BEQ $9C20
  ; Bank0_9C31: 85 6B         STA <$6B
  ; Bank0_9C33: 8D 0640       STA PULSE2_TIMER_LOW
  ; Bank0_9C36: B9 009F       LDA $9F00,Y
  ; Bank0_9C39: 09 08         ORA #$08
  ; Bank0_9C3B: 8D 0740       STA PULSE2_TIMER_HIGH
  ; Bank0_9C3E: 60            RTS

  Pulse2TimerNoSound:
    TAY
    LDA $9F01,Y

    BEQ Pulse2TimerNoSound_BranchDestination
   Pulse2TimerNoSound_BranchSource:

    STA <$6B
    LDA $8000
    LDA $9F00,Y
    ORA #$08
    NOP
    NOP
   
   Pulse2TimerNoSound_BranchDestination:
    RTS

  .IF >Pulse2TimerNoSound_BranchSource != >Pulse2TimerNoSound_BranchDestination
  .ERROR Branch target does not reside on same page; cycle count will be 1 too high.
  .ENDIF


  ; Bank0_9C3F: A8            TAY
  ; Bank0_9C40: B9 019F       LDA $9F01,Y
  ; Bank0_9C43: F0 DB         BEQ $9C20
  ; Bank0_9C45: 8D F005       STA $05F0
  ; Bank0_9C48: 8D 0A40       STA TRIANGLE_TIMER_LOW
  ; Bank0_9C4B: B9 009F       LDA $9F00,Y
  ; Bank0_9C4E: 09 08         ORA #$08
  ; Bank0_9C50: 8D 0B40       STA TRIANGLE_TIMER_HIGH
  ; Bank0_9C53: 60            RTS

  TriangleTimerNoSound:
    TAY
    LDA $9F01,Y
    BEQ TriangleTimerNoSound_BranchDestination
   TriangleTimerNoSound_BranchSource:

    STA $05F0
    LDA $8000
    LDA $9F00,Y
    ORA #$08
    NOP
    NOP

   TriangleTimerNoSound_BranchDestination:
    RTS

  .IF >TriangleTimerNoSound_BranchSource != >TriangleTimerNoSound_BranchDestination
  .ERROR Branch target does not reside on same page; cycle count will be 1 too high.
  .ENDIF


  .IF $ > $8D60
  .ERROR Exceeded free region.
  .ENDIF



.PATCH $1D7A  ; CODE
.BASE  $9D6A

  ; Bank0_9D6A: 20 2B9C       JSR $9C2B

    JSR Pulse2TimerNoSound


  .IF $ != $9D6D
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1D85  ; CODE
.BASE  $9D75

  ; Bank0_9D75: 20 219C       JSR $9C21

    JSR PulseNoSound


  .IF $ != $9D78
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1DA6  ; CODE
.BASE  $9D96

  ; Bank0_9D96: 8D 0440       STA PULSE2_CONTROL
  ; Bank0_9D99: A2 7F         LDX #$7F
  ; Bank0_9D9B: 8E 0540       STX PULSE2_SWEEP
  ; Bank0_9D9E: AD 0906       LDA $0609

    LDA $8000
    LDX #$7F
    LDA $8000


  .IF $ != $9D9E
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1DBB  ; CODE
.BASE  $9DAB

  ; Bank0_9DAB: 8E 0640       STX PULSE2_TIMER_LOW
  ; Bank0_9DAE: AC 0B06       LDY $060B

    LDY $8000


  .IF $ != $9DAE
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1DE5  ; CODE
.BASE  $9DD5

  ; Bank0_9DD5: 20 0D9C       JSR $9C0D

    JSR Pulse1TimerNoSound


  .IF $ != $9DD8
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1DF0  ; CODE
.BASE  $9DE0

  ; Bank0_9DE0: 20 039C       JSR $9C03

    JSR PulseNoSound


  .IF $ != $9DE3
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1E11  ; CODE
.BASE  $9E01

  ; Bank0_9E01: 8D 0040       STA PULSE1_CONTROL
  ; Bank0_9E04: AD 0906       LDA $0609

    LDA $8000


  .IF $ != $9E04
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1E21  ; CODE
.BASE  $9E11

  ; Bank0_9E11: 8E 0240       STX PULSE1_TIMER_LOW
  ; Bank0_9E14: A9 7F         LDA #$7F
  ; Bank0_9E16: 8D 0140       STA PULSE1_SWEEP
  ; Bank0_9E19: AD 0C06       LDA $060C

    LDA $8000
    LDA #$7F
    LDA $8000


  .IF $ != $9E19
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1E6D  ; CODE
.BASE  $9E5D

  ; Bank0_9E5D: 8D 0840       STA TRIANGLE_CONTROL
  ; Bank0_9E60: AC 0C06       LDY $060C

    LDY $8000


  .IF $ != $9E60
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1E7A  ; CODE
.BASE  $9E6A

  ; Bank0_9E6A: 20 3F9C       JSR $9C3F

    JSR TriangleTimerNoSound


  .IF $ != $9E6D
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1E94  ; CODE
.BASE  $9E84

  ; Bank0_9E84: 8E 0A40       STX TRIANGLE_TIMER_LOW
  ; Bank0_9E87: AD F105       LDA $05F1

    LDA $8000


  .IF $ != $9E87
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1EA2  ; CODE
.BASE  $9E92

  ; Bank0_9E92: 8D 0840       STA TRIANGLE_CONTROL
  ; Bank0_9E95: AD 0906       LDA $0609

    LDA $8000


  .IF $ != $9E95
  .ERROR Patch is wrong length.
  .ENDIF



.PATCH $1ED4  ; CODE
.BASE  $9EC4

  ; Bank0_9EC4: 8D 0C40       STA NOISE_CONTROL
  ; Bank0_9EC7: B9 D89E       LDA $9ED8,Y
  ; Bank0_9ECA: 8D 0E40       STA NOISE_TIMER_LOW
  ; Bank0_9ECD: B9 DC9E       LDA $9EDC,Y
  ; Bank0_9ED0: 8D 0F40       STA NOISE_TIMER_HIGH
  ; Bank0_9ED3: 60            RTS

    LDA $8000
    LDA $9ED8,Y
    LDA $8000
    LDA $9EDC,Y

    ; Because we want to be absolutely sure we don't change the behavior of
    ; anything after the RTS, we use 2 NOPs here for the same cycle count
    ; instead of a 4 cycle instruction that would change registers or flags.
    ; The old RTS is left in place for anything that may branch to it.
    NOP  ; 2 cycles.
    NOP  ; 2 cycles.
    RTS


  .IF $ != $9ED3
  .ERROR Patch is wrong length.
  .ENDIF