; To build: snarfblasm.exe buffet.asm -INVALID:OFF


; Controls which version of the game (PRG0 or PRG1) to tailor the patch to.
dVersionIsPrg1 := $00

; The version to print in the BUFFET VERSION menu option.
dBuffetVersionMajor := $01
dBuffetVersionMinor := $02


current_level        := $10  ; #$00 = Overworld/Caves, #$01-09 = Dungeons.
current_task         := $11
current_mode         := $12
current_state        := $13
current_ppu_sequence := $14
frame_counter        := $15
current_save_slot    := $16  ; 0-2 (3 and 4 for selection screen options).
random_lfsr          := $18
delay_game_timer     := $3C
sword_disable_timer  := $4C  ; Runs off of stun_timer_tick.
ten_count            := $50
drop_forced_bomb     := $51
moving_door_status   := $54  ; 2-4 closing, 0 done, 6-8 opening
current_moving_door  := $55  ; UDLR.
entrance_type_unknown := $5A
switch_base_nametable := $5C
enemy_target_pos_x   := $61
enemy_target_pos_y   := $62

entrance_tile        := $65  ; If #$24, exiting underground areas will behave as a cave entrance (climbing stairs).
                             ; Otherwise, Link just appears.
pause_status         := $E0  ; 0 = unpaused. Bit 1 = healing-paused. Bit 0 = select-paused.
start_menu_status    := $E1
is_scrolling         := $E3
current_screen       := $EB
opened_doors         := $EE  ; UDLR. Used to figure out which door to unlock when entering a room (permanent) and which doors to change
has_init_sram        := $F4
joypad1_press        := $F8  ; ABSeStUDLR. Buttons pressed this frame.
ppu_mask_value       := $FE
ppu_control_value    := $FF

mutable_ppu_sequence_size  := $0301
mutable_ppu_sequence       := $0302 

current_sprite_number := $0341  ; The number of the next sprite tile, used to find the offset of the tile in the
                                     ; sprite region.
solid_tiles_index    := $034A
num_enemies_loaded   := $034E
num_enemies_killed   := $034F
primary_object_id    := $035F


item_being_held      := $0505  ; When non-zero, the ID of the item Link is holding above his head.
held_item_timer      := $0506  ; Only decreased when Link is holding an item.
graphics_chunk_index := $051D  ; Indicates which graphics chunk should be loaded to the pattern tables.
halt_objects         := $051E  ; When set, causes all object processing to halt.
room_light_mode      := $051F
recorder_destination_counter := $0523
spawn_counter        := $0524  ; Ranges 0-8.
edge_spawn_position  := $0525  ; YX block position at which to edge-spawn an enemy.
cave_exit_screen     := $0526
kill_counter         := $052A  ; Used as an index into the enemy's group's item drop table.
fairy_counter        := $0627

is_second_quest      := $062D  ; - $62F (#$3). Indexed by save slot.

current_sword                := $0657  ; 0 = none, 1 = wooden, 2 = white, 3 = magical
num_bombs                    := $0658
current_arrow                := $0659  ; 0 = none, 1 = wooden, 2 = silver
has_bow                      := $065A
current_candle               := $065B  ; 0 = none, 1 = blue, 2 = red
has_recorder                 := $065C
has_bait                     := $065D
current_potion               := $065E  ; 0 = none, 1 = blue, 2 = red (higher values are valid, better potions, but
                                       ; are miscolored. Palette is (value-1) % 4)
has_magical_rod              := $065F
has_raft                     := $0660
has_book_of_magic            := $0661
current_ring                 := $0662  ; 0 = none, 1 = blue, 2 = red (higher values are valid, better rings, but
                                       ; are miscolored. Palette is (value-1) % 4)
has_stepladder               := $0663
has_magical_key              := $0664
has_power_bracelet           := $0665
has_letter                   := $0666
has_compass                  := $0667  ; 1 bit per level
has_map                      := $0668  ; 1 bit per level
has_compass_level_9          := $0669
has_map_level_9              := $066A

has_clock                    := $066C
num_rupees                   := $066D
num_keys                     := $066E
health                       := $066F  ; High nybble = total heart containers - 1, Low nybble = filled heart containers.
health_fraction              := $0670  ; 0 = empty, 1-7F = appears half full, 80-ff = appears full.
has_triforce                 := $0671  ; 1 bit per level
has_triforce_of_power        := $0672

has_boomerang                := $0674
has_magical_boomerang        := $0675
has_magical_shield           := $0676

max_bombs                    := $067C


dungeon_screen_enemy_status  := $0560  ; - $5DF (#$80). Low nybble = enemies killed.
recent_screens               := $0621  ; - $626 (#$6). Most recently visited screens. If not on this list and all enemies are killed, enemies 
overworld_screen_status      := $067F  ; - $6FE (#$80). Flags:
                                       ; 7:   Bomb/fire secret found
                                       ; 5:   Bracelet-shortcut staircase found
                                       ; 4:   Item collected
                                       ; 2-0: Enemies killed. If all killed, set to 111. Does not track Zora.
dungeon_screen_status_map1   := $06FF  ; - $77E (#$80). Flags for levels 1-6:
                                       ; 7:   All enemies killed?
                                       ; 6:   All enemies killed?
                                       ; 5:   Visited (mapped)
                                       ; 4:   Item collected
                                       ; 3-0: UDLR door unlocked
dungeon_screen_status_map2   := $077F  ; - $7FE (#$80). Flags for levels 7-9:
                                       ; 7:   All enemies killed?
                                       ; 6:   All enemies killed?
                                       ; 5:   Visited (mapped)
                                       ; 4:   Item collected
                                       ; 3-0: UDLR door unlocked


link_pos_x := $70
link_pos_y := $84
link_face_direction := $98
link_subgrid_offset  := $0394
link_subpos          := $03A8
link_speed := $03BC
link_collision_tile := $049E
link_iframes := $4F0

object_pos_x := $70
object_pos_y := $84
object_face_direction := $98
object_status := $AC
dynamic_id := $34F
object_subgrid_offset := $0394


current_area_table_0   := $687E
current_area_table_1   := $68FE
current_area_table_2   := $697E
current_area_table_3   := $69FE
current_area_table_4   := $6A7E
current_area_table_5   := $6AFE
current_level_metadata := $6B7E


; New variables.
show_target := $4F
nmi_counter := $F0
scroll_type := $F1
secs   := $110
frames := $111
show_lag := $112
force_update := $113
is_menu_active := $114
current_menu_state := $115
current_menu_entry := $116
change_flags := $117
current_byte_cache := $118
current_address_low := $119
current_address_high := $11A
show_ganon := $11B
scroll_fast := $11C
dummy_var := $11D
force_entry_screen := $11E
menu_entry_invalid := $11F
force_enemies := $120
force_enemy_id := $121
force_enemy_quantity := $122
screen_warp_flags := $123
lanmola_attempt_counter := $124
deal_no_damage := $125
immortal_link := $126
cached_darkness_flag := $127
current_forced_door := $128
last_graphics_set := $129
disable_wall_sprites := $12A

sram_region := $7FE0
hide_practice_hud := $7FF5
time_transitions := $7FF6
passive_hud := $7FF7
sram_region_end := $7FF8

sram_signature := $7FF8
sram_signature_end := $7FFF


BuildHudPpuSequence := $6CC0
GetOppositeDirection := $7013
AbsoluteValue := $701F
SetUpDoorframeSprites := $7512
UseJumpTable := $E5E2
dBitTable := $E6BE
AdvanceMode := $EBA1
SwitchBank := $FFAC


.IF !dVersionIsPrg1
InitMode09 := $910A
InitMode0B := $9080
InitMode0C := $9097
.ELSE
InitMode09 := $9114
InitMode0B := $908A
InitMode0C := $90A1
.ENDIF


PPU_CONTROL   := $2000
PPU_MASK      := $2001
PPU_STATUS    := $2002
PPU_ADDRESS   := $2006
PPU_DATA      := $2007
SOUND_CONTROL := $4015  ; Write-only



.PATCH 01:8D34

  JMP PatchCopyRegionToSram



.PATCH 01:A13E

; Optimizes this function to only check one slot for the moving block instead of all of them. This saves a constant
; amount of time each frame of around 300 cycles.
; HandleMovingBlockCollision:
  LDA dynamic_id + $0B
  CMP #$68
  BEQ +
  CMP #$62
  BEQ +
  CMP #$65
  BEQ +
  CMP #$66
  BNE HandleMovingBlockCollision_Done
 +

  LDA <object_status + $0B,X
  CMP #$01
  BNE HandleMovingBlockCollision_Done

  LDA <link_pos_x
  SEC
  SBC <object_pos_x + $0B,X
  JSR AbsoluteValue
  CMP #$10
  BCS HandleMovingBlockCollision_Done

  LDA <link_pos_y
  CLC
  ADC #$03
  SEC
  SBC <object_pos_y + $0B,X
  JSR AbsoluteValue
  CMP #$10
  BCS HandleMovingBlockCollision_Done

  LDA #$00
  STA <$0F

 HandleMovingBlockCollision_Done:
  RTS



.PATCH $7761
.BASE  $7EE1

ShowTarget:
  ; If show_target is enabled, draw an indicator at the position enemies target.
  LDA show_target
  BNE +
  JMP $E78A

 +
  LDA enemy_target_pos_y
  STA $025C  ; Y.

  LDA #$45
  STA $025D  ; Tile ID.

  LDA #$02
  STA $025E  ; Flags.

  LDA enemy_target_pos_x
  STA $025F  ; X.

  JMP $E78A

  .IF $ > $8000
  .ERROR ShowTarget too long.
  .ENDIF



.PATCH 01:B800

dImmortalBytesBank1:
  .db $20,$A3,$EB,$8D,$70,$06
 dImmortalBytesBank1_End:
  .db $A9,$00,$8D,$70,$06,$60

PatchCopyRegionToSram:
  ; Deal no damage.
  LDA #$60  ; RTS
  LDX deal_no_damage
  BNE +
  LDA #$BD  ; LDA Absolute,X
 +
  STA $7C59  ; Hit success.

  ; Immortal Link.
  LDX #<(dImmortalBytesBank1_End - dImmortalBytesBank1 - 1)
  LDA immortal_link
  BEQ +
  LDX #<(((dImmortalBytesBank1_End- dImmortalBytesBank1) * 2) - 1)
 +
  
  LDY #<(dImmortalBytesBank1_End - dImmortalBytesBank1 - 1)

 -
  LDA dImmortalBytesBank1,X
  STA $7BB1,Y
  DEX
  DEY
  BPL -

  RTS



.PATCH 02:8A8F

  .INCBIN "practice_hud_graphics.dat"

  .IF $ > $8D7F
  .ERROR "practice_hud_graphics.dat" too large (max $270 bytes).
  .ENDIF



.PATCH 02:8F60

PatchGameStart:
  ; Need to set the timer on game start in case the timer is measuring transitions.
  LDA #$00
  STA secs
  STA frames
  JMP AdvanceMode


  .IF $ > $9000
  .ERROR Exceeded free region.
  .ENDIF



.PATCH 02:9BD7

; Bit 0-7 for levels 1-8, and both bits 6 and 7 for level 9.
dValidDungeonScreens:
  ; First quest.
  .db $08|$00,$08|$C0,$08|$C0,$08|$C0,$00|$C0,$10|$C0,$10|$C0,$00|$C0,$00|$40,$20|$40,$20|$40,$20|$40,$20|$40,$02|$40,$02|$80,$00|$00
  .db $08|$C0,$08|$C0,$08|$C0,$08|$C0,$10|$C0,$10|$C0,$10|$C0,$10|$C0,$20|$40,$20|$40,$20|$40,$20|$40,$20|$40,$20|$80,$02|$80,$02|$80
  .db $08|$C0,$08|$C0,$01|$C0,$01|$C0,$10|$C0,$10|$C0,$10|$C0,$10|$C0,$20|$40,$20|$40,$04|$40,$04|$40,$20|$80,$20|$80,$02|$80,$02|$00
  .db $08|$C0,$08|$C0,$08|$C0,$01|$C0,$10|$C0,$01|$C0,$01|$C0,$10|$C0,$20|$40,$20|$40,$20|$40,$04|$80,$20|$80,$04|$80,$02|$80,$02|$80
  .db $08|$C0,$01|$C0,$01|$C0,$01|$C0,$01|$C0,$01|$C0,$10|$C0,$10|$C0,$20|$40,$04|$40,$04|$00,$04|$80,$04|$80,$04|$80,$02|$80,$02|$00
  .db $08|$C0,$08|$C0,$01|$C0,$01|$C0,$01|$C0,$10|$C0,$10|$C0,$10|$C0,$20|$40,$04|$40,$04|$40,$04|$40,$04|$80,$04|$80,$02|$80,$02|$80
  .db $00|$00,$08|$C0,$08|$C0,$01|$C0,$10|$C0,$10|$C0,$10|$C0,$10|$00,$20|$40,$04|$40,$20|$40,$04|$40,$02|$40,$02|$40,$02|$80,$02|$00
  .db $08|$00,$08|$C0,$01|$00,$01|$C0,$01|$C0,$00|$00,$10|$C0,$10|$00,$20|$40,$20|$40,$20|$40,$04|$00,$04|$80,$02|$80,$02|$80,$00|$80
  ; Second quest.
  .db $08|$C0,$08|$C0,$08|$00,$00|$00,$20|$00,$20|$00,$20|$C0,$01|$C0,$01|$40,$00|$40,$04|$40,$00|$40,$10|$40,$10|$40,$10|$40,$00|$40
  .db $08|$C0,$08|$C0,$08|$C0,$20|$C0,$20|$C0,$02|$C0,$20|$C0,$01|$C0,$01|$40,$04|$40,$04|$80,$04|$80,$10|$80,$10|$80,$10|$80,$10|$40
  .db $02|$00,$00|$00,$08|$C0,$20|$C0,$20|$C0,$02|$C0,$20|$00,$01|$00,$00|$40,$04|$40,$04|$80,$04|$00,$10|$00,$10|$40,$10|$80,$10|$40
  .db $02|$00,$08|$C0,$08|$C0,$20|$C0,$20|$C0,$02|$C0,$20|$C0,$01|$00,$01|$40,$04|$40,$04|$80,$04|$80,$10|$80,$10|$40,$10|$80,$10|$40
  .db $08|$C0,$08|$C0,$20|$C0,$20|$C0,$20|$C0,$02|$C0,$00|$C0,$01|$C0,$01|$40,$04|$40,$04|$80,$04|$80,$10|$80,$10|$40,$10|$80,$10|$40
  .db $08|$C0,$20|$C0,$20|$C0,$20|$C0,$20|$C0,$02|$C0,$00|$C0,$01|$C0,$00|$40,$04|$40,$04|$80,$04|$80,$10|$80,$10|$40,$10|$80,$10|$40
  .db $08|$00,$08|$C0,$08|$C0,$20|$C0,$20|$C0,$02|$C0,$02|$C0,$01|$00,$01|$40,$04|$40,$00|$40,$04|$40,$10|$40,$10|$40,$10|$80,$10|$40
  .db $08|$00,$08|$00,$08|$00,$00|$C0,$20|$C0,$02|$00,$02|$00,$01|$00,$01|$80,$04|$80,$00|$80,$04|$80,$10|$80,$10|$80,$10|$80,$00|$40


; Low nybble for animation frames for the arrow and overline.
dMenuArrowRowOffsets:
  .db $07,$09,$0B,$09


; Strings.
dValueBoolYes:
  .db $22,$e,$1c
 dValueBoolYes_End:

dValueBoolNo:
  .db $17,$18
 dValueBoolNo_End:

dValueConfirm:
  .db $c,$18,$17,$f,$12,$1b,$16,$2e
 dValueConfirm_End:


; Invalid enemy IDs.
dInvalidEnemies:
  .db $11  ; Zora
  .db $18  ; Digdogger (small)
  .db $19  ; (empty)
  .db $1E  ; Armos
  .db $25  ; Patra satellite (3D)
  .db $26  ; Patra satellite (2D)
  .db $29  ; (empty)
 dInvalidEnemies_End:


  .IF $ > $9D00
  .ERROR Exceeded free region.
  .ENDIF



.PATCH 02:A635

  JSR PatchGameStart



.PATCH 02:AF90

 --
  JMP HandlePracticeMenu  

 -
  ; If unpausing, this needs to take 15 frames.
  CPX #$01
  BNE --
  DEX
  STA is_menu_active
  NOP
  JMP HandleModeGameplayTask1_DoUnpause  

 --
  RTS

HandleModeGameplayTask1:
  LDA <delay_game_timer
  BNE --
  LDA halt_objects
  BEQ +
  JMP HandleFrame_DoHaltedObjects

 +
  ; 12
  LDA start_menu_status
  BNE HandleModeGameplay_CheckSubscreen

  LDY #$F8

  LDX is_menu_active
  BNE -

  LDA pause_status
  LSR
  BNE HandleModeGameplay_HandlePause
;15
  LDA joypad1_press
  AND #$20
  BCC HandleModeGameplay_CheckPausing

  ; Check unpausing.
  BEQ +
 HandleModeGameplayTask1_DoUnpause:
  STY $0250
  STX pause_status
  LDA #$0F
  STA SOUND_CONTROL
  BNE HandleModeGameplay_CheckSubscreen  ; 22 cycles

; orig 36 unpausing, this 43 cycles

 +
  LDA joypad1_press
  AND #$10
  BEQ HandleModeGameplay_HandlePause
  JMP HandlePracticeMenu

 HandleModeGameplay_CheckPausing:
  BNE HandleModeGameplay_InitPause

 HandleModeGameplay_CheckSubscreen:
  JMP HandleFrame_ContinueBank7

; orig 21 cycles, this 28 cycles
; Both paths are now 7 cycles longer.

 HandleModeGameplay_InitPause:
  ; Place the sprite indicating that Start opens the menu.
  LDA #$2D
  STA $0250
  LDA #$3F
  STA $0251
  LDA #$02
  STA $0252
  LDA #$7C
  STA $0253

  INC pause_status

 HandleModeGameplay_HandlePause:
  JMP HandleFrame_FinishHandlePause



; Menu entry modes.
kEditModeByte := $00
kEditModeBinary := $01
kEditModeBool := $02
kEditModeConfirm := $03
kEditModeMemory := $04
kEditModeVersion := $05


; Pointers to the various menu entry structs.
dMenuEntryPointers:
 dMenuPage1:
 dMenuSpecialLevel:
  .dw dMenuLevel
 dMenuSpecialScreen:
  .dw dMenuScreen
  .dw dMenuLinkPosX
  .dw dMenuLinkPosY
 dMenuSpecialLinkSubgridOffset:
  .dw dMenuLinkSubgridOffset
  .dw dMenuLinkSubposition
 dMenuPage2:
  .dw dMenuGlobalCounter
  .dw dMenuStreakCounter
  .dw dMenuStoredBomb
  .dw dMenuFairyCounter
  .dw dMenuRecorderCounter
  .dw dMenuSpawnCounter
 dMenuSpecialEdgeSpawn:
  .dw dMenuEdgeSpawnPosition
 dMenuPage3:
 dMenuSpecialHealth:
  .dw dMenuHealth
  .dw dMenuHealthFraction
  .dw dMenuSword
  .dw dMenuBoomerang
  .dw dMenuMagicalBoomerang
  .dw dMenuBombs
  .dw dMenuBombCapacity
  .dw dMenuBow
  .dw dMenuArrow
  .dw dMenuCandle
  .dw dMenuRecorder
  .dw dMenuBait
  .dw dMenuLetter
  .dw dMenuPotion
  .dw dMenuMagicalRod
  .dw dMenuRaft
  .dw dMenuBookOfMagic
 dMenuSpecialRing:
  .dw dMenuRing
  .dw dMenuStepladder
  .dw dMenuMagicalKey
  .dw dMenuPowerBracelet
  .dw dMenuMagicalShield
  .dw dMenuClock
  .dw dMenuRupees
  .dw dMenuKeys
 dMenuSpecialMap:
  .dw dMenuMap
 dMenuSpecialMapLevel9:
  .dw dMenuMapLevel9
  .dw dMenuCompass
  .dw dMenuCompassLevel9
  .dw dMenuTriforce
  .dw dMenuTriforceOfPower
 dMenuPage4:
 dMenuLastPage:
 dMenuSpecialDealNoDamage:
  .dw dMenuDealNoDamage
 dMenuSpecialImmortalLink:
  .dw dMenuImmortalLink
 dMenuSpecialClearScreen:
  .dw dMenuClearScreen
 dMenuSpecialRestoreScreen:
  .dw dMenuRestoreScreen
 dMenuSpecialRestoreLevel:
  .dw dMenuRestoreLevel
 dMenuSpecialRestoreWorld:
  .dw dMenuRestoreWorld
 dMenuSpecialForceEnemies:
  .dw dMenuForceEnemies
  .dw dMenuForceEnemyQuantity
 dMenuSpecialForceEnemyId:
  .dw dMenuForceEnemyId
  .dw dMenuShowGanon
  .dw dMenuShowTarget
 dMenuSpecialHideWallSprites:
  .dw dMenuHideWallSprites
  .dw dMenuShowPerfMonitor
  .dw dMenuFastDungeonScroll
 dMenuSpecialHidePracticeHud:
  .dw dMenuHidePracticeHud
  .dw dMenuPassiveHud
  .dw dMenuTimeTransitions
 dMenuSpecialEditMemory:
  .dw dMenuEditMemory
 dMenuSpecialVersion:
  .dw dMenuVersion
 dMenuEntryPointers_End:

dMenuPages:
  .db <((dMenuPage1 - dMenuEntryPointers) >> 1)
  .db <((dMenuPage2 - dMenuEntryPointers) >> 1)
  .db <((dMenuPage3 - dMenuEntryPointers) >> 1)
  .db <((dMenuPage4 - dMenuEntryPointers) >> 1)
 dMenuPages_Terminator:
  .db $FF


; Menu entry structs. Format is:
;   word: variable address
;   byte: mode
;   (if mode == kEditModeByte) byte: Limit (upper bound). Lower bound is assumed to be 00.
;   char[]: FF-terminated string.
dMenuLevel:
  .dw current_level
  .db kEditModeByte
  .db $09
  .db $15,$e,$1f,$e,$15
  .db $FF
dMenuScreen:
  .dw current_screen
  .db kEditModeByte
  .db $7F
  .db $1c,$c,$1b,$e,$e,$17
  .db $FF
dMenuLinkPosX:
  .dw link_pos_x
  .db kEditModeByte
  .db $FF
  .db $15,$12,$17,$14,$24,$19,$18,$1c,$12,$1d,$12,$18,$17,$24,$21
  .db $FF
dMenuLinkPosY:
  .dw link_pos_y
  .db kEditModeByte
  .db $FF
  .db $15,$12,$17,$14,$24,$19,$18,$1c,$12,$1d,$12,$18,$17,$24,$22
  .db $FF
dMenuLinkSubgridOffset:
  .dw link_subgrid_offset
  .db kEditModeByte
  .db $FF
  .db $15,$12,$17,$14,$24,$1c,$1e,$b,$10,$1b,$12,$d,$24,$19,$18,$1c,$2c
  .db $FF
dMenuLinkSubposition:
  .dw link_subpos
  .db kEditModeByte
  .db $FF
  .db $15,$12,$17,$14,$24,$1c,$1e,$b,$19,$12,$21,$e,$15,$24,$19,$18,$1c,$2c
  .db $FF
dMenuGlobalCounter:
  .dw kill_counter
  .db kEditModeByte
  .db $09
  .db $10,$15,$18,$b,$a,$15,$24,$c,$18,$1e,$17,$1d,$e,$1b
  .db $FF
dMenuStreakCounter:
  .dw ten_count
  .db kEditModeByte
  .db $0A
  .db $1c,$1d,$1b,$e,$a,$14,$24,$c,$18,$1e,$17,$1d,$e,$1b
  .db $FF
dMenuStoredBomb:
  .dw drop_forced_bomb
  .db kEditModeBool
  .db $1c,$1d,$18,$1b,$e,$d,$24,$b,$18,$16,$b
  .db $FF
dMenuFairyCounter:
  .dw fairy_counter
  .db kEditModeByte
  .db $FF
  .db $f,$a,$12,$1b,$22,$24,$c,$18,$1e,$17,$1d,$e,$1b
  .db $FF
dMenuRecorderCounter:
  .dw recorder_destination_counter
  .db kEditModeByte
  .db $FF
  .db $1b,$e,$c,$18,$1b,$d,$e,$1b,$24,$c,$18,$1e,$17,$1d,$e,$1b
  .db $FF
dMenuSpawnCounter:
  .dw spawn_counter
  .db kEditModeByte
  .db $08
  .db $1c,$19,$a,$20,$17,$24,$c,$18,$1e,$17,$1d,$e,$1b
  .db $FF
dMenuEdgeSpawnPosition:
  .dw edge_spawn_position
  .db kEditModeByte
  .db $FF
  .db $e,$d,$10,$e,$24,$1c,$19,$a,$20,$17,$24,$19,$18,$1c,$2c
  .db $FF
dMenuHealth:
  .dw health
  .db kEditModeByte
  .db $FF
  .db $11,$e,$a,$15,$1d,$11
  .db $FF
dMenuHealthFraction:
  .dw health_fraction
  .db kEditModeByte
  .db $FF
  .db $11,$e,$a,$15,$1d,$11,$24,$f,$1b,$a,$c,$1d,$12,$18,$17
  .db $FF
dMenuSword:
  .dw current_sword
  .db kEditModeByte
  .db $03
  .db $1c,$20,$18,$1b,$d
  .db $FF
dMenuBoomerang:
  .dw has_boomerang
  .db kEditModeBool
  .db $b,$18,$18,$16,$e,$1b,$a,$17,$10
  .db $FF
dMenuMagicalBoomerang:
  .dw has_magical_boomerang
  .db kEditModeBool
  .db $16,$a,$10,$12,$c,$a,$15,$24,$b,$18,$18,$16,$e,$1b,$a,$17,$10
  .db $FF
dMenuBombs:
  .dw num_bombs
  .db kEditModeByte
  .db $FF
  .db $b,$18,$16,$b,$1c
  .db $FF
dMenuBombCapacity:
  .dw max_bombs
  .db kEditModeByte
  .db $FF
  .db $b,$18,$16,$b,$24,$c,$a,$19,$a,$c,$12,$1d,$22
  .db $FF
dMenuBow:
  .dw has_bow
  .db kEditModeBool
  .db $b,$18,$20
  .db $FF
dMenuArrow:
  .dw current_arrow
  .db kEditModeByte
  .db $02
  .db $a,$1b,$1b,$18,$20
  .db $FF
dMenuCandle:
  .dw current_candle
  .db kEditModeByte
  .db $02
  .db $c,$a,$17,$d,$15,$e
  .db $FF
dMenuRecorder:
  .dw has_recorder
  .db kEditModeBool
  .db $1b,$e,$c,$18,$1b,$d,$e,$1b
  .db $FF
dMenuBait:
  .dw has_bait
  .db kEditModeBool
  .db $b,$a,$12,$1d
  .db $FF
dMenuLetter:
  .dw has_letter
  .db kEditModeByte
  .db $02
  .db $15,$e,$1d,$1d,$e,$1b
  .db $FF
dMenuPotion:
  .dw current_potion
  .db kEditModeByte
  .db $02
  .db $19,$18,$1d,$12,$18,$17
  .db $FF
dMenuMagicalRod:
  .dw has_magical_rod
  .db kEditModeBool
  .db $16,$a,$10,$12,$c,$a,$15,$24,$1b,$18,$d
  .db $FF
dMenuRaft:
  .dw has_raft
  .db kEditModeBool
  .db $1b,$a,$f,$1d
  .db $FF
dMenuBookOfMagic:
  .dw has_book_of_magic
  .db kEditModeBool
  .db $b,$18,$18,$14,$24,$18,$f,$24,$16,$a,$10,$12,$c
  .db $FF
dMenuRing:
  .dw current_ring
  .db kEditModeByte
  .db $02
  .db $1b,$12,$17,$10
  .db $FF
dMenuStepladder:
  .dw has_stepladder
  .db kEditModeBool
  .db $1c,$1d,$e,$19,$15,$a,$d,$d,$e,$1b
  .db $FF
dMenuMagicalKey:
  .dw has_magical_key
  .db kEditModeBool
  .db $16,$a,$10,$12,$c,$a,$15,$24,$14,$e,$22
  .db $FF
dMenuPowerBracelet:
  .dw has_power_bracelet
  .db kEditModeBool
  .db $19,$18,$20,$e,$1b,$24,$b,$1b,$a,$c,$e,$15,$e,$1d
  .db $FF
dMenuMagicalShield:
  .dw has_magical_shield
  .db kEditModeBool
  .db $16,$a,$10,$12,$c,$a,$15,$24,$1c,$11,$12,$e,$15,$d
  .db $FF
dMenuClock:
  .dw has_clock
  .db kEditModeBool
  .db $c,$15,$18,$c,$14
  .db $FF
dMenuRupees:
  .dw num_rupees
  .db kEditModeByte
  .db $FF
  .db $1b,$1e,$19,$e,$e,$1c
  .db $FF
dMenuKeys:
  .dw num_keys
  .db kEditModeByte
  .db $FF
  .db $14,$e,$22,$1c
  .db $FF
dMenuMap:
  .dw has_map
  .db kEditModeBinary
  .db $16,$a,$19,$1c
  .db $FF
dMenuMapLevel9:
  .dw has_map_level_9
  .db kEditModeBool
  .db $16,$a,$19,$24,$15,$e,$1f,$e,$15,$24,$9
  .db $FF
dMenuCompass:
  .dw has_compass
  .db kEditModeBinary
  .db $c,$18,$16,$19,$a,$1c,$1c,$e,$1c
  .db $FF
dMenuCompassLevel9:
  .dw has_compass_level_9
  .db kEditModeBool
  .db $c,$18,$16,$19,$a,$1c,$1c,$24,$15,$e,$1f,$e,$15,$24,$9
  .db $FF
dMenuTriforce:
  .dw has_triforce
  .db kEditModeBinary
  .db $1d,$1b,$12,$f,$18,$1b,$c,$e,$24,$1e,$17,$12,$1d,$1c
  .db $FF
dMenuTriforceOfPower:
  .dw has_triforce_of_power
  .db kEditModeBool
  .db $1d,$1b,$12,$f,$18,$1b,$c,$e,$24,$18,$f,$24,$19,$18,$20,$e,$1b
  .db $FF
dMenuDealNoDamage:
  .dw deal_no_damage
  .db kEditModeBool
  .db $d,$e,$a,$15,$24,$17,$18,$24,$d,$a,$16,$a,$10,$e
  .db $FF
dMenuImmortalLink:
  .dw immortal_link
  .db kEditModeBool
  .db $12,$16,$16,$18,$1b,$1d,$a,$15,$24,$15,$12,$17,$14
  .db $FF
dMenuForceEnemies:
  .dw force_enemies
  .db kEditModeBool
  .db $f,$18,$1b,$c,$e,$24,$e,$17,$e,$16,$12,$e,$1c
  .db $FF
dMenuForceEnemyId:
  .dw force_enemy_id
  .db kEditModeByte
  .db $7F
  .db $f,$18,$1b,$c,$e,$24,$e,$17,$e,$16,$22,$24,$12,$d
  .db $FF
dMenuForceEnemyQuantity:
  .dw force_enemy_quantity
  .db kEditModeByte
  .db $08
  .db $f,$18,$1b,$c,$e,$24,$e,$17,$e,$16,$22,$24,$a,$16,$18,$1e,$17,$1d
  .db $FF
dMenuClearScreen:
  .dw dummy_var
  .db kEditModeConfirm
  .db $c,$15,$e,$a,$1b,$24,$e,$17,$e,$16,$12,$e,$1c
  .db $FF
dMenuRestoreScreen:
  .dw dummy_var
  .db kEditModeConfirm
  .db $1b,$e,$1c,$e,$1d,$24,$1c,$c,$1b,$e,$e,$17
  .db $FF
dMenuRestoreLevel:
  .dw dummy_var
  .db kEditModeConfirm
  .db $1b,$e,$1c,$e,$1d,$24,$15,$e,$1f,$e,$15
  .db $FF
dMenuRestoreWorld:
  .dw dummy_var
  .db kEditModeConfirm
  .db $1b,$e,$1c,$e,$1d,$24,$20,$18,$1b,$15,$d
  .db $FF
dMenuShowGanon:
  .dw show_ganon
  .db kEditModeBool
  .db $1c,$11,$18,$20,$24,$10,$a,$17,$18,$17
  .db $FF
dMenuShowTarget:
  .dw show_target
  .db kEditModeBool
  .db $1c,$11,$18,$20,$24,$1d,$a,$1b,$10,$e,$1d
  .db $FF
dMenuHideWallSprites:
  .dw disable_wall_sprites
  .db kEditModeBool
  .db $11,$12,$d,$e,$24,$20,$a,$15,$15,$24,$1c,$19,$1b,$12,$1d,$e,$1c
  .db $FF
dMenuShowPerfMonitor:
  .dw show_lag
  .db kEditModeBool
  .db $1c,$11,$18,$20,$24,$19,$e,$1b,$f,$2c,$24,$16,$18,$17,$12,$1d,$18,$1b
  .db $FF
dMenuFastDungeonScroll:
  .dw scroll_fast
  .db kEditModeBool
  .db $f,$a,$1c,$1d,$24,$d,$1e,$17,$10,$e,$18,$17,$24,$1c,$c,$1b,$15,$2c
  .db $FF
dMenuHidePracticeHud:
  .dw hide_practice_hud
  .db kEditModeBool
  .db $11,$12,$d,$e,$24,$19,$1b,$a,$c,$1d,$12,$c,$e,$24,$11,$1e,$d
  .db $FF
dMenuPassiveHud:
  .dw passive_hud
  .db kEditModeBool
  .db $15,$e,$1c,$1c,$24,$a,$c,$1d,$12,$1f,$e,$24,$11,$1e,$d
  .db $FF
dMenuTimeTransitions:
  .dw time_transitions
  .db kEditModeBool
  .db $1d,$12,$16,$e,$24,$1d,$1b,$a,$17,$1c,$12,$1d,$12,$18,$17,$1c
  .db $FF
dMenuEditMemory:
  .dw $0008  ; Mostly a dummy value.
  .db kEditModeMemory
  .db $e,$d,$12,$1d,$24,$16,$e,$16,$18,$1b,$22
  .db $FF
dMenuVersion:
  .dw dummy_var
  .db kEditModeVersion
  .db $b,$1e,$f,$f,$e,$1d,$24,$1f,$e,$1b,$1c,$12,$18,$17
  .db $FF


; Valid edge spawns for restricting the variable to valid values.
dValidEdgeSpawns:
  .db $40,$50,$60,$70,$80,$90,$A0,$B0,$C0,$D0
  .db $E1,$E2,$E3,$E4,$E5,$E6,$E7,$E8,$E9,$EA,$EB,$EC,$ED,$EE,$EF
  .db $DF,$CF,$BF,$AF,$9F,$8F,$7F,$6F,$5F
  .db $4E,$4D,$4C,$4B,$4A,$49,$48,$47,$46,$45,$44,$43,$42,$41
 dValidEdgeSpawns_End:
  .db $00


ForceDoorTrampoline:
  LDA #>(DoorCloseWrapper - 1)
  PHA
  LDA #<(DoorCloseWrapper - 1)
  PHA

  LDA #$05
  JMP SwitchBank


CopyCustomSpriteGraphicsTrampoline:
  LDA #>(CopyCustomSpriteGraphicsWrapper - 1)
  PHA
  LDA #<(CopyCustomSpriteGraphicsWrapper - 1)
  PHA

  LDA #$03
  JMP SwitchBank


HandlePracticeMenu:
  LDA ppu_mask_value
  AND #$FE
  STA ppu_mask_value

  LDA #$00
  STA menu_entry_invalid

  ; If the menu is active, run it.
  BIT is_menu_active
  BMI HandlePracticeMenu_MenuActive
  BVC HandlePracticeMenu_ActivateMenu

  ; We're unpausing. This is the delay frame needed for clearing out the HUD. Set up for returning to gameplay.
  LDX #$01
  STX is_menu_active

  JSR HandleChangeFlags

  JMP BuildHudPpuSequence


 HandlePracticeMenu_MenuActive:
  LDA current_forced_door
  BEQ +

  STA current_moving_door

  LDA #$03
  STA moving_door_status

  JSR ForceDoorTrampoline

  LSR current_forced_door

  LDA #$00
  STA current_moving_door
  STA moving_door_status

  RTS

 +
  JSR GetMenuPointers

  ; Handle the input. If something changed and the HUD needs to be updated, $06 will be set.
  JSR HandleMenuInput
  LDA $06
  BNE HandlePracticeMenu_BuildPpuSequence

  ; If the memory editor is selected, update every frame.
  LDA current_menu_entry
  CMP #<((dMenuSpecialEditMemory - dMenuEntryPointers)/2)
  BNE +
  JSR LoadMemoryEditorValue
  JMP HandlePracticeMenu_BuildPpuSequence
 +

  ; Animate the arrow.
  LDA frame_counter
  LSR
  LSR
  LSR
  AND #$03
  TAY
  LDA $0251
  AND #$F0
  ORA dMenuArrowRowOffsets,Y
  STA $0251  ; Tile ID.

  JMP BuildHudPpuSequence
  

 HandlePracticeMenu_ActivateMenu:
  LDA #$80
  STA is_menu_active

  ; Stash the current screen's darkness flag in case we warp from it.
  LDX #$00
  LDY current_screen
  LDA current_level
  BEQ +
  LDA current_area_table_4,Y
  AND #$80
  TAX
 +
  STX cached_darkness_flag

 HandlePracticeMenu_BuildPpuSequence:
  JSR CheckMenuEntryValid

  JSR GetMenuPointers

  JSR DrawMenuArrow

  ; Set up the PPU sequence.
  LDA #$20
  STA mutable_ppu_sequence
  LDA #$E0
  STA mutable_ppu_sequence+1
  LDA #$20
  STA mutable_ppu_sequence+2
  LDA #$FF
  STA mutable_ppu_sequence+3+32
  LDA #$23
  STA mutable_ppu_sequence_size

  ; Clear the buffer.
  LDA #$24
  LDY #$1F
 -
  STA mutable_ppu_sequence+3,Y
  DEY
  BPL -

  ; Write the page number.
  JSR GetCurrentMenuPage
  STY mutable_ppu_sequence+3+2
  LDA #$2C
  STA mutable_ppu_sequence+3+3

  ; Copy over the text.
  LDY #$FF
 -
  INY
  LDA ($04),Y
  BMI +
  STA mutable_ppu_sequence+3+4,Y
  BPL -
 +

  ; Write the target value to the buffer.
  ; First, load the cached value if we're editing the entry, or the real value otherwise.
  LDA current_menu_state
  BNE +
  LDY #$00
  LDA ($02),Y
  JMP ++
 +
  LDA current_byte_cache
 ++
  PHA

  ; Get the mode number to figure out how to write the value.
  LDY #$02
  LDA ($00),Y
  TAX

  ; Draw a floppy disk icon if this variable is in SRAM.
  CMP kEditModeMemory
  BEQ +
  LDA $03
  CMP #$60
  BCC +
  LDA #$41
  STA mutable_ppu_sequence+3+30
 +  

  PLA
  DEX
  BPL HandlePracticeMenu_BuildPpuSequence_CheckModeBinary

  LDY #28
 HandlePracticeMenu_BuildPpuSequence_ModeByte:
  ; Write as a hex byte.
  ; Stash the value, since we need to pull out nybbles individually.
  TAX

  ; If there is an upper limit and it's under #$10, then only draw 1 digit.
  LDA $0F
  BEQ +
  CMP #$10
  BCC ++
 +

  ; Upper nybble.
  TXA
  LSR
  LSR
  LSR
  LSR
  STA mutable_ppu_sequence+3,Y

 ++
  ; Lower nybble.
  TXA
  AND #$0F
  STA mutable_ppu_sequence+4,Y

  ; If we're editing the level, indicate whether a warp is set up.
  LDA current_menu_entry
  CMP #<((dMenuSpecialLevel - dMenuEntryPointers)/2)
  BNE +

  LDA change_flags
  BMI HandlePracticeMenu_BuildPpuSequence_ModeByte_DrawCheckmark
  RTS

 +
  ; If we're editing the screen, indicate whether a warp is set up.
  CMP #<((dMenuSpecialScreen - dMenuEntryPointers)/2)
  BNE +

  BIT change_flags
  BVC HandlePracticeMenu_BuildPpuSequence_ModeByte_Done

 HandlePracticeMenu_BuildPpuSequence_ModeByte_DrawCheckmark:
  LDA #$40
  STA mutable_ppu_sequence+3+30
  RTS

 +
  ; If we're editing a ring, we also need to update Link's palette.
  LDA current_menu_entry
  CMP #<((dMenuSpecialRing - dMenuEntryPointers)/2)
  BNE HandlePracticeMenu_BuildPpuSequence_ModeByte_Done

  ; Append a PPU sequence that writes Link's new color to the appropriate sprite palette address.
  LDA #$3F
  STA mutable_ppu_sequence+3+32+0
  LDA #$11
  STA mutable_ppu_sequence+3+32+1
  LDA #$01
  STA mutable_ppu_sequence+3+32+2

  ; Set the ring color and note that Link should use this color in general.
  LDX current_save_slot
  LDY current_ring
  LDA $7325,Y  ; Link colors.
  STA mutable_ppu_sequence+3+32+3
  LDY $EA0E,X
  STA $6804,Y

  LDA #$FF
  STA mutable_ppu_sequence+3+32+4

  LDA #3+32+4
  STA mutable_ppu_sequence_size

 HandlePracticeMenu_BuildPpuSequence_ModeByte_Done:
  RTS


 HandlePracticeMenu_BuildPpuSequence_CheckModeBinary:
  DEX
  BPL HandlePracticeMenu_BuildPpuSequence_CheckModeBool

  ; Write as binary.
  ; 8 digits, with 0 or 1 for each.
  LDX #$07
 -
  LSR
  TAY
  LDA #$00
  BCC +
  LDA #$01
 +
  STA mutable_ppu_sequence+3+22,X
  TYA
  DEX
  BPL -

  RTS


 HandlePracticeMenu_BuildPpuSequence_CheckModeBool:
  DEX
  BPL HandlePracticeMenu_BuildPpuSequence_CheckModeConfirm

  ; Write as a bool.
  CMP #$00
  BEQ +

  ; True.
  LDY #<((dValueBoolYes_End - dValueBoolYes) - 1)
 -
  LDA dValueBoolYes,Y
  STA mutable_ppu_sequence+3+30 - <(dValueBoolYes_End - dValueBoolYes),Y
  DEY
  BPL -
  RTS


 +
  ; False.
  LDY #<((dValueBoolNo_End - dValueBoolNo) - 1)
 -
  LDA dValueBoolNo,Y
  STA mutable_ppu_sequence+3+30 - <(dValueBoolNo_End - dValueBoolNo),Y
  DEY
  BPL -
  RTS


 HandlePracticeMenu_BuildPpuSequence_CheckModeConfirm:
  DEX
  BPL HandlePracticeMenu_BuildPpuSequence_CheckModeMemory

  ; Only write in the value field when editing the value. No need to ask for confirmation when just browsing the menu.
  LDA current_menu_state
  BEQ HandlePracticeMenu_BuildPpuSequence_Done

  ; Confirm?
  LDY #<((dValueConfirm_End - dValueConfirm) - 1)
 -
  LDA dValueConfirm,Y
  STA mutable_ppu_sequence+3+30 - <(dValueConfirm_End - dValueConfirm),Y
  DEY
  BPL -
  RTS


 HandlePracticeMenu_BuildPpuSequence_CheckModeMemory:
  DEX
  BPL HandlePracticeMenu_BuildPpuSequence_CheckModeVersion

  ; Draw as 3 hex bytes.
  LDY #23
  LDA current_address_high
  JSR HandlePracticeMenu_BuildPpuSequence_ModeByte
  LDY #25
  LDA current_address_low
  JSR HandlePracticeMenu_BuildPpuSequence_ModeByte
  LDY #28
  LDA current_byte_cache
  JMP HandlePracticeMenu_BuildPpuSequence_ModeByte


 HandlePracticeMenu_BuildPpuSequence_CheckModeVersion:
  DEX
  BPL HandlePracticeMenu_BuildPpuSequence_Done

  ; Major.Minor
  LDA #dBuffetVersionMajor
  STA mutable_ppu_sequence+3+27
  LDA #$2C
  STA mutable_ppu_sequence+3+28
  LDA #dBuffetVersionMinor
  STA mutable_ppu_sequence+3+29
  ; RTS


 HandlePracticeMenu_BuildPpuSequence_Done:
  RTS


; $00-01 = Pointer to menu entry struct.
; $02-03 = Pointer to target value.
; $04-05 = Pointer to menu entry string.
GetMenuPointers:
  LDA #$00
  STA $0F

  ; Get the current entry's text pointer.
  LDA current_menu_entry
  ASL
  TAX
  LDA dMenuEntryPointers,X
  STA $00
  LDA dMenuEntryPointers+1,X
  STA $01

  ; Get a pointer to the target value.
  LDY #$00
  LDA ($00),Y
  TAX
  INY
  LDA ($00),Y
  STX $02
  STA $03

  ; Get a pointer to the string. If this uses byte mode, there's also a limit we need to skip over.
  CLC
  INY
  LDA ($00),Y
  BNE +
  ; Save the limit for later and set carry to adjust the string pointer.
  INY
  LDA ($00),Y
  STA $0F
  SEC
 +
  LDA $00
  ADC #$03
  STA $04
  LDA $01
  ADC #$00
  STA $05  

  RTS


; Returns the page number in Y, one-indexed.
GetCurrentMenuPage:
  LDY #$FF
  LDA current_menu_entry
 -
  INY
  CMP dMenuPages,Y
  BCS -

 GetCurrentMenuPage_Done:
  RTS


CheckMenuEntryValid:
  LDY current_menu_entry

  ; If this is the version display, mark it invalid; we don't want it to be editable.
  CPY #<((dMenuSpecialVersion - dMenuEntryPointers)/2)
  BEQ CheckMenuEntryValid_Invalid

  ; Validate the enemy ID we're forcefully loading.
  CPY #<((dMenuSpecialForceEnemyId - dMenuEntryPointers)/2)
  BEQ CheckMenuEntryValid_CheckEnemy

  ; Validate the screen for the current level.
  CPY #<((dMenuSpecialScreen - dMenuEntryPointers)/2)
  BNE CheckMenuEntryValid_Done

  ; If we're in the right menu state, allow editing the screen entry.
  LDA current_menu_state
  BEQ CheckMenuEntryValid_Done

  ; Always allow negative values, which take us out of the current area.
  LDA current_byte_cache
  BMI CheckMenuEntryValid_Done

 CheckMenuEntryValid_CheckScreenInLevel:
  TAX

  ; If this is second quest, adjust the index to the second quest values.
  LDY current_save_slot
  LDA is_second_quest,Y
  BEQ +
  TXA
  ORA #$80
  TAX
 +

  ; If this is the overworld, allow all screens.
  LDY current_level
  BEQ CheckMenuEntryValid_Done

 CheckMenuEntryValid_CheckScreenInLevel_SkipSetup:
  ; Get the level flag value into A. Levels 1-8 use bits 0-7 as flags. Level 9 uses #$C0 due to lack of an extra bit,
  ; since levels 7 and 8 are on the same map and can never share screens. Levels 7-9 must match exactly in bits 7 and
  ; 8.
  LDA #$C0
  CPY #$09
  BCS +
  LDA dBitTable-1,Y
 +
  STA $07

  ; While $07 contains the value that we need to match, A contains the mask we use to get the bits we care about. For
  ; dungeons 1-6, that's just the level's flag, but for 7-9, we need to match perfectly in the top two bits.
  CMP #$40
  BCC +
  LDA #$C0
 +
  AND dValidDungeonScreens,X
  CMP $07
  BNE CheckMenuEntryValid_Invalid
  RTS


 CheckMenuEntryValid_CheckEnemy:
  ; If we're in the right menu state, allow editing the ID.
  LDA current_menu_state
  BEQ CheckMenuEntryValid_Done

  LDY #<(dInvalidEnemies_End - dInvalidEnemies - 1)
  LDA current_byte_cache
 -
  CMP dInvalidEnemies,Y
  BEQ CheckMenuEntryValid_Invalid
  DEY
  BPL -

  ; Projectiles and special objects.
  CMP #$53
  BCC CheckMenuEntryValid_Done
  CMP #$62
  BCS CheckMenuEntryValid_Done

 CheckMenuEntryValid_Invalid:
  INC menu_entry_invalid

 CheckMenuEntryValid_Done:
  RTS


HandleMenuInput:
  ; Default to marking that the menu needs to be redrawn. If we reach the end and nothing happened, we can clear this.
  LDA #$01
  STA $06

  ; Choose between handling menu entries or value editing.
  LDA current_menu_state
  BEQ +
  JMP HandleValueEditing

 +
  ; We're selecting menu entries, not editing them.
  LDA joypad1_press
  LSR
  BCC HandleMenuInput_CheckLeft

  ; Right (next page).
  JSR GetCurrentMenuPage

  ; If we went past the last page (page start index is the terminator value), wrap back to the first page.
  LDA dMenuPages,Y
  CMP #$FF
  BNE +
  LDY #$00
 +
  LDA dMenuPages,Y
  STA current_menu_entry

  RTS


 HandleMenuInput_CheckLeft:
  LSR
  BCC HandleMenuInput_CheckDown

  ; Left (previous page).
  JSR GetCurrentMenuPage

  ; If we're on the first page, choose the terminator page before decrementing to wrap to the last page.
  DEY
  BNE +
  LDY #<(dMenuPages_Terminator - dMenuPages)
 +
  DEY
  LDA dMenuPages,Y
  STA current_menu_entry

  RTS


 HandleMenuInput_CheckDown:
  LSR
  BCC HandleMenuInput_CheckUp

  ; Down (next entry).
  JSR GetCurrentMenuPage

  ; Find the first entry past this page.
  LDA dMenuPages,Y
  CMP #$FF
  BNE +
  LDA #((dMenuEntryPointers_End - dMenuEntryPointers)/2)
 +

  ; Increment the entry. If it's gone beyond this page, return to the start of the page.
  INC current_menu_entry
  CMP current_menu_entry
  BNE +
  LDA dMenuPages-1,Y
  STA current_menu_entry
 +

  RTS

 HandleMenuInput_CheckUp:
  LSR
  BCC HandleMenuInput_CheckSelect

  ; Up (previous entry).
  JSR GetCurrentMenuPage

  ; If this isn't the first entry of the page, just decrement it.
  LDA dMenuPages-1,Y
  CMP current_menu_entry
  BEQ +
  DEC current_menu_entry
  RTS

 +
  ; Load the first entry of the next page and then decrement it to wrap to the end of the current page.
  LDX dMenuPages,Y
  CPX #$FF
  BNE +
  LDX #((dMenuEntryPointers_End - dMenuEntryPointers)/2)
 +
  DEX
  STX current_menu_entry
  RTS

 HandleMenuInput_CheckSelect:
  LSR
  LSR
  BCC HandleMenuInput_CheckA

  ; Select (exit menu).
  ; Mark that we're exiting so we can do the delay frame.
  LSR is_menu_active

  ; Clear our the cursor sprite.
  LDA #$F8
  STA $0250

  ; Clear the menu off the HUD.
  LDA #$7E
  STA current_ppu_sequence

  ; We're exiting the menu and want to clear it out, so claim we did nothing so we don't try to redraw the entry.
  BNE HandleMenuInput_NoChange  ; Unconditional.

 HandleMenuInput_CheckA:
  LSR
  LSR
  BCC HandleMenuInput_NoChange

  ; A (edit entry).
  JSR CheckMenuEntryValid
  LDA menu_entry_invalid
  BNE HandleMenuInput_NoChange

  ; Start editing the entry.
  INC current_menu_state

  ; If this is the memory editor, get the current value of the current memory editor address.
  LDA current_menu_entry
  CMP #<((dMenuSpecialEditMemory - dMenuEntryPointers)/2)
  BNE +
  JMP LoadMemoryEditorValue
 +

  ; Get the current value of the address.
  LDY #$00
  LDA ($02),Y
  STA current_byte_cache
  RTS

 HandleMenuInput_NoChange:
  LDA #$00
  STA $06
  RTS


EditEdgeSpawns:
  ; Find the current entry.
  LDY #<(dValidEdgeSpawns_End - dValidEdgeSpawns - 1)
  LDA dValidEdgeSpawns,Y
  LDA current_byte_cache
 -
  CMP dValidEdgeSpawns,Y
  BEQ +
  DEY
  BNE -
 +

  ; Pick the next or previous entry depending on direction.
  LDA joypad1_press
  AND #$01
  BEQ EditEdgeSpawns_CheckPrevious

  ; Next.
  INY
  CPY #<(dValidEdgeSpawns_End - dValidEdgeSpawns)
  BNE +
  LDY #$00
 +
  LDA dValidEdgeSpawns,Y
  STA current_byte_cache
  RTS


 EditEdgeSpawns_CheckPrevious:
  LDA joypad1_press
  AND #$02
  BEQ HandleMenuInput_NoChange

  ; Previous.
  DEY
  CPY #$FF
  BNE +
  LDY #<(dValidEdgeSpawns_End - dValidEdgeSpawns - 1)
 +
  LDA dValidEdgeSpawns,Y
  STA current_byte_cache
  RTS



; Subgrid offset goes #$F9-07, so it won't work with the normal limit system.
ApplyLimitPositive_LinkSubgridOffset:
  STA current_byte_cache

  CMP #$F9
  BCS +

  CMP #$08
  BCC +

  LDA #$F9
  STA current_byte_cache

 +
  RTS


; Beam swords don't work if current health is above max health, so prevent it.
ApplyLimitPositive_Health:
  LDY current_byte_cache
  CPY #$FF
  BNE ++

  TAY
  BEQ ApplyLimitPositive_Health_ZeroCurrentHealth
  BNE +  ; Unconditional.

 ++
  CMP current_byte_cache
  BCS +
  LDA #$FF
  BNE ApplyLimitPositive_Health_SetValue  ; Unconditional.

 +
  STA current_byte_cache

  ;LDA current_byte_cache
  AND #$0F
  STA $07

  LDA current_byte_cache
  LSR
  LSR
  LSR
  LSR

  CMP $07
  BCS +
 ApplyLimitPositive_Health_ZeroCurrentHealth:
  LDA current_byte_cache
  AND #$F0
 ApplyLimitPositive_Health_SetValue:
  STA current_byte_cache
 +
  RTS


; Takes the amount to add in Y.
ApplyLimitPositive:
  CLC
  ADC current_byte_cache

  ; Handle subgrid offset and health limits using their own special logic.
  LDX current_menu_entry
  CPX #<((dMenuSpecialHealth - dMenuEntryPointers)/2)
  BEQ ApplyLimitPositive_Health
  CPX #<((dMenuSpecialLinkSubgridOffset - dMenuEntryPointers)/2)
  BEQ ApplyLimitPositive_LinkSubgridOffset

  ; If the value is equal to the upper limit, set to 0.
  LDY current_byte_cache
  CPY $0F
  BNE +
  LDA #$00
  BEQ ApplyLimitPositive_Done  ; Unconditional.

 +
  ; If we wrapped around (became less despite adding), set to the limit.
  CMP current_byte_cache
  BCC ApplyLimitPositive_SetToLimit

  ; If we're above the limit, set to the limit.
  CMP $0F
  BCC ApplyLimitPositive_Done

 ApplyLimitPositive_SetToLimit:
  LDA $0F

 ApplyLimitPositive_Done:
  STA current_byte_cache
  RTS


; Subgrid offset goes #$F9-07, so it won't work with the normal limit system.
ApplyLimitNegative_LinkSubgridOffset:
  STA current_byte_cache

  CMP #$08
  BCC +

  CMP #$F9
  BCS +

  LDA #$07
  STA current_byte_cache

 +
  RTS


; Beam swords don't work if current health is above max health, so prevent it.
ApplyLimitNegative_Health:
  LDY current_byte_cache
  BNE +

  CMP #$FF
  BNE ++
  LDA #$00
  BEQ ApplyLimitNegative_Health_SetValue  ; Unconditional.
  
 ++
  LDA #$FF
  BNE ApplyLimitNegative_Health_SetValue  ; Unconditional.

 +
  STA current_byte_cache

  ; Save current health.
  AND #$0F
  STA $07

  ; Get max health.
  LDA current_byte_cache
  LSR
  LSR
  LSR
  LSR

  ; If max health >= current health, we're in-bounds.
  CMP $07
  BCS +

  ; Save max health as current health.
  STA $07

  ; Save whether we got here from pressing left.
  LDA joypad1_press
  AND #$02
  TAY

  ; Set current health to max health.
  LDA current_byte_cache
  AND #$F0
  ORA $07

  ; If we got here by pressing left, then we went from, say, #$80 to #$7F and are now #$77 when we want to be #$88. So,
  ; fix this up by adding 1 to each of max and current health.
  CPY #$02
  BNE ++
  CLC
  ADC #$11
 ++
 ApplyLimitNegative_Health_SetValue:
  STA current_byte_cache

 +
  RTS


ApplyLimitNegative:
  CLC
  ADC current_byte_cache

  ; Handle subgrid offset and health limits using their own special logic.
  LDX current_menu_entry
  CPX #<((dMenuSpecialHealth - dMenuEntryPointers)/2)
  BEQ ApplyLimitNegative_Health
  CPX #<((dMenuSpecialLinkSubgridOffset - dMenuEntryPointers)/2)
  BEQ ApplyLimitNegative_LinkSubgridOffset

  ; If the value is equal to 0, set to the upper limit.
  LDY current_byte_cache
  BNE +
  LDA $0F
  JMP ApplyLimitNegative_Done

 +
  ; If we wrapped around (becomes more despite subtracting), set to 0.
  CMP current_byte_cache
  BCC +
  LDA #$00
 +

 ApplyLimitNegative_Done:
  STA current_byte_cache
  RTS



EditValueModeByte:
  ; Edge spawns are handled in their own way.
  LDA current_menu_entry
  CMP #<((dMenuSpecialEdgeSpawn - dMenuEntryPointers)/2)
  BNE +
  JMP EditEdgeSpawns
 +

  ; Right (+1).
  LDA joypad1_press
  LSR
  BCC +
  LDA #$01
  JMP ApplyLimitPositive

 +
  ; Left (-1).
  LSR
  BCC +
  LDA #$FF
  JMP ApplyLimitNegative


 +
  ; If this byte is only ever 1 digit, don't allow +/-10.
  LDY $0F
  BEQ ++
  CPY #$10
  BCC EditValueModeByte_NoChange
 ++
  LDY current_menu_entry
  CPY #<((dMenuSpecialLinkSubgridOffset - dMenuEntryPointers)/2)
  BEQ EditValueModeByte_NoChange

  ; Down (+10).
  LSR
  BCC +
  LDA #$10
  JMP ApplyLimitPositive

 +
  ; Up (-10).
  LSR
  BCC +
  LDA #$F0
  JMP ApplyLimitNegative

 +
 EditValueModeByte_NoChange:
  ; No change.
  LDA #$00
  STA $06
  RTS



EditValueModeBinary:
  LDA current_menu_entry

  ; Right (right one digit).
  LDA joypad1_press
  LSR
  BCC EditValueModeBinary_CheckLeft

  ; Move right 1 digit.
  LDY current_menu_state
  DEY
  BNE +
  LDY #$08
 +
  STY current_menu_state
  RTS


 EditValueModeBinary_CheckLeft:
  ; Left (left one digit).
  LSR
  BCC EditValueModeBinary_CheckDown

  ; Move left 1 digit.
  LDY current_menu_state
  INY
  CPY #$09
  BNE +
  LDY #$01
 +
  STY current_menu_state
  RTS


 EditValueModeBinary_CheckDown:
  ; Up and down both toggle the value.
  AND #$03
  BEQ EditValueModeBinary_NoChange

  ; Flip the bit value.
  LDY current_menu_state
  DEY
  LDA dBitTable,Y
  EOR current_byte_cache
  STA current_byte_cache

  RTS


 EditValueModeBinary_NoChange:
  ; No change.
  LDA #$00
  STA $06
  RTS



EditValueModeBool:
  ; Left and right toggle the value.
  LDA joypad1_press
  AND #$03
  BEQ EditValueModeBinary_NoChange

  ; Flip between false (zero) and true (non-zero).
  CLC
  LDA current_byte_cache
  BNE +
  SEC
 +
  LDA #$00
  ROL
  STA current_byte_cache
  RTS



EditValueModeMemory_DoPositive:
  ; If this is the top digit of the address, we need to restrict it to valid memory regions.
  LDA current_menu_state
  CMP #$06
  BEQ EditValueModeMemory_DoPositive_TopmostNybble

  ; Otherwise, we can do common handling of ones and of tens.
  SBC #$00  ; Zero-index it.
  LSR
  TAY
  LDA current_byte_cache,Y
  BCS EditValueModeMemory_DoPositive_UpperNybbles

  ; Low nybble.
  TAX
  AND #$F0
  STA $07
  INX
  TXA
  AND #$0F
  ORA $07
  STA current_byte_cache,Y
  RTS


 EditValueModeMemory_DoPositive_UpperNybbles:
  ; C == 1.
  ADC #$0F
  STA current_byte_cache,Y
  RTS


 EditValueModeMemory_DoPositive_TopmostNybble:
  LDA current_byte_cache+2
  CLC
  ADC #$10
  CMP #$80
  BCC +
  ; >= #$80, so set to #$0x.
  AND #$0F
  JMP EditValueModeMemory_DoPositive_WriteTopmost

 +
  CMP #$60
  BCS EditValueModeMemory_DoPositive_WriteTopmost

  CMP #$20
  BCC EditValueModeMemory_DoPositive_WriteTopmost
  ; >= #$20, so set to #$6x.
  AND #$0F
  ORA #$60

 EditValueModeMemory_DoPositive_WriteTopmost:
  STA current_byte_cache+2
  RTS



EditValueModeMemory_DoNegative:
  ; If this is the top digit of the address, we need to restrict it to valid memory regions.
  LDA current_menu_state
  CMP #$06
  BEQ EditValueModeMemory_DoNegative_TopmostNybble

  ; Otherwise, we can do common handling of ones and of tens.
  SBC #$00  ; Zero-index it.
  LSR
  TAY
  LDA current_byte_cache,Y
  BCS EditValueModeMemory_DoNegative_UpperNybbles

  ; Low nybble.
  TAX
  AND #$F0
  STA $07
  DEX
  TXA
  AND #$0F
  ORA $07
  STA current_byte_cache,Y
  RTS


 EditValueModeMemory_DoNegative_UpperNybbles:
  ; C == 1.
  SBC #$10
  STA current_byte_cache,Y
  RTS


 EditValueModeMemory_DoNegative_TopmostNybble:
  LDA current_byte_cache+2
  SEC
  SBC #$10
  CMP #$80
  BCC +
  ; >= #$80, so set to #$7x.
  AND #$0F
  ORA #$70
  JMP EditValueModeMemory_DoNegative_WriteTopmost

 +
  CMP #$60
  BCS EditValueModeMemory_DoNegative_WriteTopmost

  CMP #$20
  BCC EditValueModeMemory_DoNegative_WriteTopmost
  ; >= #$20, so set to #$1x.
  AND #$0F
  ORA #$10

 EditValueModeMemory_DoNegative_WriteTopmost:
  STA current_byte_cache+2
  RTS


; In order to remember its address, the memory editor doesn't use the address in the menu entry.
LoadMemoryEditorValue:
  LDA current_menu_state
  BEQ +
  CMP #$03
  BCC ++
 +
  LDA current_address_low
  STA $08
  LDA current_address_high
  STA $09
  LDY #$00
  LDA ($08),Y
  STA current_byte_cache

 ++
  RTS


EditValueModeMemory:
  ; Right (right one digit).
  LDA joypad1_press
  LSR
  BCC EditValueModeMemory_CheckLeft

  ; Move right 1 digit.
  LDY current_menu_state
  DEY
  BNE +
  LDY #$06
 +
  STY current_menu_state
  RTS


 EditValueModeMemory_CheckLeft:
  ; Left (left one digit).
  LSR
  BCC EditValueModeMemory_CheckDown

  ; Move left 1 digit.
  LDY current_menu_state
  INY
  CPY #$07
  BNE +
  LDY #$01
 +
  STY current_menu_state
  RTS

 EditValueModeMemory_CheckDown:
  ; Down (+10).
  LSR
  BCC EditValueModeMemory_CheckUp

  JSR EditValueModeMemory_DoPositive
  JMP LoadMemoryEditorValue

 EditValueModeMemory_CheckUp:
  ; Up (-10).
  LSR
  BCC EditValueModeMemory_NoChange

  JSR EditValueModeMemory_DoNegative
  JMP LoadMemoryEditorValue

 EditValueModeMemory_NoChange:
  ; No change.
  LDA #$00
  STA $06
 EditValueModeMemory_Return:
  RTS


RestoreCommon:
  LDX #$00
  STX num_enemies_killed

  ; Collected items are moved off the bottom of the screen, so we need to restore the Y position.
  LDA current_level
  BEQ +

  LDA #$08
  STA current_forced_door
  STX opened_doors

  ; This is a dungeon, so just get the Y position for this screen.
  JSR $718A
 --
  STY $97
 -
  LDA #$00
  RTS

 +
  ; This is the overworld, so check if this is the screen with the heart container or power bracelet.
  LDA current_mode
  CMP #$05
  BNE -

  LDA current_screen
  CMP #$5F  ; Heart container screen.
  BEQ +
  CMP #$24  ; Power bracelet screen.
  BNE -

  LDY #$80
  BNE ++  ; Unconditional.
 +
  LDY #$90
 ++

  STX $BF
  BNE --  ; Unconditional.



; Clears out all killed-enemy state.
CommitValueModeConfirm:
  LDA current_menu_entry
  CMP #<((dMenuSpecialClearScreen - dMenuEntryPointers)/2)
  BNE +
  JMP CommitValueModeConfirm_ClearScreen
 +
  CMP #<((dMenuSpecialRestoreScreen - dMenuEntryPointers)/2)
  BNE +
  JMP EditValueModeConfirm_RestoreScreen
 +
  CMP #<((dMenuSpecialRestoreLevel - dMenuEntryPointers)/2)
  BNE +
  JMP EditValueModeConfirm_RestoreLevel
 +
  CMP #<((dMenuSpecialRestoreWorld - dMenuEntryPointers)/2)
  BNE EditValueModeMemory_Return
  JMP EditValueModeConfirm_RestoreWorld


 EditValueModeConfirm_RestoreScreen:
  JSR RestoreCommon

  LDY current_screen
  LDX current_level
  BNE +
  STA overworld_screen_status,Y
  RTS

 +
  STA dungeon_screen_enemy_status,Y
  CPX #$07
  BCS +
  STA dungeon_screen_status_map1,Y
  RTS

 +
  STA dungeon_screen_status_map2,Y
  RTS


; Up to 2 screens for each dungeon that are passageways containing items. If a dungeon only has 1 screen, it should be
; repeated. If it has none, both should be $FF.
dPassagewayList:
  ; First quest.
  .db $7F,$7F
  .db $FF,$FF
  .db $0F,$0F
  .db $60,$60
  .db $04,$04
  .db $75,$75
  .db $4A,$4A
  .db $0F,$6F
  .db $00,$4F

  ; Second quest.
  .db $FF,$FF
  .db $FF,$FF
  .db $0B,$0B
  .db $7A,$7A
  .db $6A,$7F
  .db $46,$46
  .db $2B,$2C
  .db $70,$70
  .db $77,$76


 EditValueModeConfirm_RestoreLevel:
  JSR RestoreCommon

  LDX current_level
  BNE +

  ; Overworld.
  LDY #$7F
 -
  STA overworld_screen_status,Y
  DEY
  BPL -
  RTS

 +

  LDA #$00
  STA $07

  ; If this is second quest, adjust the index to the second quest values.
  LDY current_save_slot
  LDA is_second_quest,Y
  BEQ +
  LDA #$80
  STA $07
  LDA #$09
 +

  CLC
  ADC current_level
  ASL

  LDY current_level
  CPY #$07
  BCS +

  ; Map 1.
  TAY
  LDX dPassagewayList-2,Y
  BMI ++
  LDA #$00
  STA dungeon_screen_status_map1,X
  LDX dPassagewayList-1,Y
  STA dungeon_screen_status_map1,X
 ++

  LDY current_level
  LDX $07

 -
  JSR CheckMenuEntryValid_CheckScreenInLevel_SkipSetup
  LDA menu_entry_invalid
  BNE ++
  TXA
  PHA
  AND #$7F
  TAX
  LDA #$00
  STA dungeon_screen_enemy_status,X
  STA dungeon_screen_status_map1,X
  PLA
  TAX

 ++
  LDA #$00
  STA menu_entry_invalid

  INX
  TXA
  AND #$7F
  BNE -
  RTS
  

 +
  ; Map 2.
  TAY
  LDX dPassagewayList-2,Y
  BMI ++
  LDA #$00
  STA dungeon_screen_status_map2,X
  LDX dPassagewayList-1,Y
  STA dungeon_screen_status_map2,X
 ++

  LDY current_level
  LDX $07

 -
  JSR CheckMenuEntryValid_CheckScreenInLevel_SkipSetup
  LDA menu_entry_invalid
  BNE ++
  TXA
  PHA
  AND #$7F
  TAX
  LDA #$00
  STA dungeon_screen_enemy_status,X
  STA dungeon_screen_status_map2,X
  PLA
  TAX

 ++
  LDA #$00
  STA menu_entry_invalid

  INX
  TXA
  AND #$7F
  BNE -
  RTS


 EditValueModeConfirm_RestoreWorld:
  ; Current screen.
  JSR RestoreCommon

  ; Dungeon enemies.
  TAY
 -
  STA dungeon_screen_enemy_status,Y
  INY
  BPL -

  ; Overworld.
  TAY
 -
  ;LDA overworld_screen_status,Y
  ;AND #$F8
  STA overworld_screen_status,Y
  INY
  BPL -

  ; Dungeon bosses. This does both #$80-byte maps.
  LDY #$00
 -
  ;LDA dungeon_screen_status_map1,Y
  ;AND #$3F
  STA dungeon_screen_status_map1,Y
  INY
  BNE -

  ; Recent screens.
  ; LDY #$05
  ; LDA #$FF
 ; -
  ; STA recent_screens,Y
  ; DEY
  ; BPL -

  RTS


 CommitValueModeConfirm_ClearScreen:
  LDY #$0B
 -
  LDA dynamic_id,Y
  CMP #$5D
  BCS +

  LDA #$00
  STA dynamic_id,Y
 +

  DEY
  BNE -

  RTS


CommitValueModeMemory:
  LDA current_address_low
  STA $08
  LDA current_address_high
  STA $09

  LDA current_byte_cache
  LDY #$00
  STA ($08),Y
  RTS


HandleValueEditing:
  ; A (commit).
  BIT joypad1_press
  BMI +
  JMP HandleValueEditing_CheckB
 +

  ; If the value isn't valid, don't commit.
  JSR CheckMenuEntryValid
  LDA menu_entry_invalid
  BEQ +
  JMP HandleValueEditing_NoChange
 +

  LDY #$02
  LDA ($00),Y

  ; Stop editing.
  LDY #$00
  STY current_menu_state

  ; Some modes require special handling.
  CMP #kEditModeConfirm
  BNE +
  JMP CommitValueModeConfirm
 +
  CMP #kEditModeMemory
  BNE +
  JMP CommitValueModeMemory
 +

  ; If the byte changed, we need to check if either force enemy option changed so we can load appropriate graphics.
  LDA ($02),Y
  CMP current_byte_cache
  BEQ ++

  LDA current_menu_entry
  CMP #<((dMenuSpecialForceEnemies - dMenuEntryPointers)/2)
  BNE +
  LDA current_byte_cache
  STA ($02),Y
  ; LDY #$00
  JMP CopyCustomSpriteGraphicsTrampoline

 +
  CMP #<((dMenuSpecialForceEnemyId - dMenuEntryPointers)/2)
  BNE +
  LDA current_byte_cache
  STA ($02),Y
  INY  ; LDY #$01
  JMP CopyCustomSpriteGraphicsTrampoline

 +
 ++
  ; Commit the byte.
  LDA current_byte_cache
  STA ($02),Y

  JMP HandleValueEditing_PostCommitSpecialBehavior

 HandleValueEditing_CheckB:
  ; B (cancel).
  BVC +

  ; Cancel. Stop editing and return to the standard menu.
  LDY #$00
  STY current_menu_state
  RTS

 +
  ; Enter the edit handler for this mode.
  LDY #$02
  LDA ($00),Y

  TAY
  BNE +
  JMP EditValueModeByte

 +
  DEY
  BNE +
  JMP EditValueModeBinary

 +
  DEY
  BNE +
  JMP EditValueModeBool

 +
  DEY
  BEQ HandleValueEditing_NoChange  ; Commit mode.

  DEY
  BNE +
  JMP EditValueModeMemory

 +
 HandleValueEditing_NoChange:
  ; No change.
  LDA #$00
  STA $06
  RTS


 HandleValueEditing_PostCommitSpecialBehavior:
  ; If we updated the level number, we need to set up a level transition later.
  LDA current_menu_entry
  CMP #<((dMenuSpecialLevel - dMenuEntryPointers)/2)
  BNE +

  ; Enter level.
  LDA change_flags
  ORA #$80
  STA change_flags
  RTS

 +
  ; If we updated the screen index, we need to set up a screen transition later.
  CMP #<((dMenuSpecialScreen - dMenuEntryPointers)/2)
  BNE +

  ; Enter screen.
  LDA change_flags
  ORA #$40
  STA change_flags
  RTS

 +
  ; If we updated deal no damage, we need to update the SRAM code.
  CMP #<((dMenuSpecialDealNoDamage - dMenuEntryPointers)/2)
  BNE +

  ; Deal no damage.
  LDA change_flags
  ORA #$20
  STA change_flags
  RTS

 +
  CMP #<((dMenuSpecialImmortalLink - dMenuEntryPointers)/2)
  BNE +

  ; Immortal Link.
  LDA change_flags
  ORA #$10
  STA change_flags
  RTS

 +
  CMP #<((dMenuSpecialMap - dMenuEntryPointers)/2)
  BEQ ++
  CMP #<((dMenuSpecialMapLevel9 - dMenuEntryPointers)/2)  
  BNE +
 ++

  ; Toggle map.
  LDA change_flags
  ORA #$08
  STA change_flags
  RTS

 +
  CMP #<((dMenuSpecialHideWallSprites - dMenuEntryPointers)/2)  
  BNE +

  ; Hide wall sprites.
  ; If this is gleeok, do nothing.
  LDA primary_object_id
  CMP #$42
  BCC ++
  CMP #$46
  BCC +++
 ++

  ; If this is the overworld, do nothing.
  LDA current_level
  BEQ +++

  ; If we're turning the feature off, set the sprites up again.
  LDA disable_wall_sprites
  BNE ++
  JMP SetUpDoorframeSprites

 ++
  ; We're turning the feature on, so clear out the sprites.
  LDY #$3C
  LDA #$F8
 -
  STA $0200,Y
  DEY
  DEY
  DEY
  DEY
  BPL -

 +++
  RTS

 +
  CMP #<((dMenuSpecialHidePracticeHud - dMenuEntryPointers)/2)  
  BNE +

  LDA change_flags
  ORA #$04
  STA change_flags
  ;RTS

 +
  RTS


dScrollingOffsetTable:
  .db $10,$F0,$01,$FF

dLevelExitScreens:
  .db $77,$37,$3C,$74,$45,$0B,$22,$42,$6D,$05
  .db $77,$37,$3C,$34,$45,$1B,$30,$19,$6C,$00

dLevelExitTiles:
  .db $70,$24,$24,$24,$24,$70,$24,$70,$70,$24
  .db $70,$24,$70,$70,$24,$70,$70,$24,$70,$24

dImmortalBytes:
  .db $20,$A3,$EB,$8D,$70,$06
 dImmortalBytes_End:
  .db $A9,$00,$8D,$70,$06,$60

; dDoorSequence:
  ; .db $21,$4F,$82,$DC,$DC, $21,$50,$82,$DC,$DC
  ; .db $23,$4F,$82,$DD,$DD, $23,$50,$82,$DD,$DD
  ; .db $22,$42,$82,$DE,$DE, $22,$43,$82,$DE,$DE
  ; .db $22,$5C,$82,$DF,$DF, $22,$5C,$82,$DF,$DF
  ; .db $FF


ForceUnpause:
  LDA #$00
  STA pause_status
  STA is_menu_active
  LDA #$0F
  STA SOUND_CONTROL
  RTS


HandleChangeFlags:
  LDA change_flags
  AND #$20
  BEQ HandleChangeFlags_CheckImmortal

  ; #$20: Deal no damage.
  ; Clear the bit.
  EOR #$FF
  AND change_flags
  STA change_flags

  LDA #$60  ; RTS
  LDX deal_no_damage
  BNE +
  LDA #$BD  ; LDA Absolute,X
 +
  STA $7C59  ; Hit success.


 HandleChangeFlags_CheckImmortal:
  LDA change_flags
  AND #$10
  BEQ HandleChangeFlags_CheckLevel

  ; #$10: Immortal Link.
  ; Clear the bit.
  EOR #$FF
  AND change_flags
  STA change_flags

  LDX #<(dImmortalBytes_End - dImmortalBytes - 1)
  LDA immortal_link
  BEQ +
  LDX #<(((dImmortalBytes_End - dImmortalBytes) * 2) - 1)
 +
  
  LDY #<(dImmortalBytes_End - dImmortalBytes - 1)

 -
  LDA dImmortalBytes,X
  STA $7BB1,Y
  DEX
  DEY
  BPL -


 HandleChangeFlags_CheckLevel:
  BIT change_flags
  BPL HandleChangeFlags_CheckMap

  ; #$80: Enter level.

  ; If the screen was also changed, set an override for the level's entry screen.
  BVC +

  ; If the screen is negative, don't use it.
  LDA current_screen
  BMI +

  ; If the screen isn't in the level, don't use it.
  JSR CheckMenuEntryValid_CheckScreenInLevel
  LDA menu_entry_invalid
  BNE +

  ; Set the entry screen and mark the top bit so we know to use the value.
  LDA current_screen
  ORA #$80
  STA force_entry_screen
 +

  JSR ForceUnpause

  ; Prevent the last screen's entrance direction from opening doors in the new level.
  LDA #$00
  STA opened_doors

  ; Start a level transition.
  LDA #$02
  STA current_mode
  LDA #$00
  STA current_task
  STA current_state

  STA entrance_type_unknown

  LDA #$70
  STA link_collision_tile

  ; Set up the exit properly to match the real level entrance.
  LDX #$00
  LDY current_save_slot
  LDA is_second_quest,Y
  BEQ +
  LDX #$0A
 +
  TXA
  CLC
  ADC current_level
  TAY
  LDA dLevelExitScreens,Y
  STA cave_exit_screen
  LDA dLevelExitTiles,Y
  STA entrance_tile

  ; Stop music and sound effects.
  JSR $6EE9
  JMP HandleChangeFlags_Done


 HandleChangeFlags_CheckMap:
  LDA change_flags
  AND #$08
  BEQ HandleChangeFlags_CheckDrawLevel

  ; Clear the flag.
  LDA change_flags
  AND #~$08
  STA change_flags

  ; The overworld doesn't have a map.
  LDY current_level
  BEQ HandleChangeFlags_CheckDrawLevel

  ; Check if we're clearing or drawing the map.
  LDA has_map_level_9
  CPY #$09
  BEQ +
  LDA dBitTable-1,Y
  AND has_map
 +
  LDX #$6E
  TAY
  BEQ +
  LDX #$44
 +
  STX current_ppu_sequence

  ; Delay a frame to do the map update.
  LDA #$40
  STA is_menu_active

  RTS


 HandleChangeFlags_CheckDrawLevel:
  LDA change_flags
  AND #$04
  BEQ HandleChangeFlags_CheckScreen

  ; Clear the flag.
  LDA change_flags
  AND #~$04
  STA change_flags

  ; If LEVEL-# doesn't need to be drawn, skip this.
  LDA hide_practice_hud
  BEQ HandleChangeFlags_CheckScreen
  LDA current_level
  BEQ HandleChangeFlags_CheckScreen

  LDA #$0C
  STA current_ppu_sequence

  ; Delay a frame to do the map update.
  LDA #$40
  STA is_menu_active

  RTS



 HandleChangeFlags_CheckScreen:
  LDA change_flags
  AND #$40
  BEQ HandleChangeFlags_Done

  ; #$40/41: Enter screen.
  ; If we're in a special screen and already fixed up the palettes, finish the special work required.
  LDA change_flags
  AND #$01
  BNE HandleChangeFlags_TransitionScreenFromSpecial

  ; If this is a cave or passageway, we need to do additional setup.
  LDA current_mode
  CMP #$05
  BEQ HandleChangeFlags_TransitionScreen

  ; We're in a cave or passageway. Set a special flag for doing more work next frame.
  LDA change_flags
  ORA #$01
  STA change_flags

  ; Add the ring color to the area metadata.
  LDX <current_save_slot
  LDY $EA0E,X
  LDA $6804,Y
  STA $6B92

  ; Request that palettes be fixed up and another delay frame on which to do this work.
  LDA #$18
  STA current_ppu_sequence 
  LDA #$40
  STA is_menu_active

  ; Finish handling this on the next frame.
  RTS

 HandleChangeFlags_TransitionScreenFromSpecial:
  ; If this is an overworld cave or we're holding an item, music is disabled, so reenable it.
  LDY #$01
  LDA current_level
  BEQ +
  LDA held_item_timer
  BEQ ++

  LDA #$00
  STA held_item_timer
  STA item_being_held
  LDY #$40
 +
  STY $0600
 ++

 HandleChangeFlags_TransitionScreen:
  ; Prevent funky scrolling.
  LDA #$00
  STA entrance_type_unknown

  ; Indicate that we shouldn't save enemies when warping.
  LDA cached_darkness_flag
  ORA #$01
  STA screen_warp_flags

  ; Align Link to a grid intersection so scrolling works more correctly.
  LDA link_pos_x
  AND #$F8
  STA link_pos_x

  LDA link_pos_y
  CLC
  ADC #$03
  AND #$F8
  SEC
  SBC #$03
  STA link_pos_y

  LDA #$00
  STA link_subgrid_offset

  JSR ForceUnpause

  ; Start the screen transition.
  LDA #$06
  STA current_mode
  LDA #$00
  STA current_task
  STA current_state

  ; Offset the index based on the direction Link is facing to get the screen Link is scrolling from.
  LDA link_face_direction
  JSR GetOppositeDirection

  LDA dScrollingOffsetTable,Y
  CLC
  ADC current_screen
  STA current_screen

 HandleChangeFlags_Done:
  LDA #$00
  STA change_flags
  RTS


dMenuCursorXPositions:
  .db $08,$E8,$E0

dMenuBinaryCursorXPositions:
  .db $E8,$E0,$D8,$D0,$C8,$C0,$B8,$B0

dMenuMemoryCursorXPositions:
  .db $E8,$E0,$D0,$C8,$C0,$B8


DrawMenuArrow_Byte:
  ; Byte.
  ; The X position depends on whether we're drawing 1 or 2 digits.
  LDA $0F
  BEQ ++
  CMP #$10
  BCS ++
  LDA #$E0
  BNE DrawMenuArrow_Common  ; Unconditional.

 ++
  LDA #$D8
  BNE DrawMenuArrow_Common  ; Unconditional.


DrawMenuArrow_Binary:
  LDY current_menu_state
  LDA dMenuBinaryCursorXPositions-1,Y
 DrawMenuArrow_DrawOverline:
  STA $0253  ; X.

  LDA #$27
  STA $0250  ; Y

  LDA frame_counter
  LSR
  LSR
  LSR
  AND #$03
  TAY
  LDA #$30
  BNE DrawMenuArrow_SetTile  ; Unconditional.


DrawMenuArrow_Bool:
  LDA current_byte_cache
  BEQ ++
  ; Yes.
  LDA #$D0
  BNE DrawMenuArrow_Common  ; Unconditional.
 ++
  ; No.
  LDA #$D8
  BNE DrawMenuArrow_Common  ; Unconditional.


DrawMenuArrow_Confirm:
  LDA #$A8
  BNE DrawMenuArrow_Common  ; Unconditional.


DrawMenuArrow_Memory:
  LDY current_menu_state
  LDA dMenuMemoryCursorXPositions-1,Y
  JMP DrawMenuArrow_DrawOverline
  


DrawMenuArrow:
  LDY current_menu_state
  BEQ DrawMenuArrow_MenuEntry

  LDY #$02
  LDA ($00),Y
  TAX
  BEQ DrawMenuArrow_Byte
  DEX
  BEQ DrawMenuArrow_Binary
  DEX
  BEQ DrawMenuArrow_Bool
  DEX
  BEQ DrawMenuArrow_Confirm
  DEX
  BEQ DrawMenuArrow_Memory


 DrawMenuArrow_MenuEntry:
  LDA #$08

 DrawMenuArrow_Common:
  STA $0253  ; X.

  LDA #$2F
  STA $0250  ; Y.

  LDA frame_counter
  LSR
  LSR
  LSR
  AND #$03
  TAY
  LDA #$40
 DrawMenuArrow_SetTile:
  ORA dMenuArrowRowOffsets,Y
  STA $0251  ; Tile ID.

  LDA #$02
  LDY menu_entry_invalid
  BEQ +
  LDA #$01
 +
  STA $0252  ; Flags.

  RTS


  .IF $ > $BF50
  .ERROR Exceeded free region.
  .ENDIF



.PATCH 03:8060

  JMP PatchLoadAreaGraphics



.PATCH 03:AC00

dAreaGraphicsDestinationPpuPointers := $8030
dDungeonGraphicsSizes := $803C

; 0: None
; 1: Overworld
; 2: Dungeon fixed
; 3: Goriya
; 4: Darknut
; 5: Wizzrobe
; 6: Aquamentus/Digdogger/Dodongo
; 7: Gleeok/Gohma/Manhandla
; 8: Ganon/Patra/Zelda

dGraphicsSetPointers:
  .dw $915B
  .dw $9CBB
  .dw $9DBB
  .dw $987B
  .dw $9A9B
  .dw $9FDB
  .dw $A3DB
  .dw $A7DB

dLevelSets:
  .db $01
  .db $63
  .db $63
  .db $74
  .db $75
  .db $64
  .db $75
  .db $63
  .db $74
  .db $85

dGraphicsSets:
  .db $00,$01,$01,$01,$01,$03,$03,$01,$01,$01,$01,$04,$04,$01,$01,$01
  .db $01,$01,$05,$04,$02,$02,$04,$05,$06,$00,$01,$02,$02,$02,$01,$01
  .db $01,$01,$01,$05,$05,$08,$08,$03,$03,$00,$03,$02,$02,$02,$01,$00
  .db $04,$06,$06,$07,$07,$00,$03,$08,$06,$06,$05,$05,$07,$06,$08,$00
  .db $00,$00,$07,$07,$07,$07,$07,$08,$08,$02,$02,$02,$02,$02,$02,$02
  .db $02,$02,$02,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
  .db $00,$00,$01,$01,$01,$01,$01,$01,$01,$01,$01,$01,$01,$04,$02,$04
  .db $04,$05,$05,$05,$04,$03,$05,$05,$04,$03,$03,$05,$05,$05,$04,$03


PatchLoadAreaGraphics:
  STA graphics_chunk_index
  LDA force_enemies
  BNE +
  RTS

 +
  ; Get the graphics set we need.
  ; LDY force_enemy_id
  ; LDA dGraphicsSets,Y
  ; TAX

  ; Does this level use the graphics set we need?
  LDY current_level
  BEQ +

  ; If this is a dungeon and the enemy uses the common graphics set, we're done.
  LDA #$02
  CMP last_graphics_set
  BEQ PatchLoadAreaGraphics_Done
 +

  ; Does this enemy use this level's enemy graphics set?
  LDA dLevelSets,Y
  TAX
  AND #$0F
  CMP last_graphics_set
  BEQ PatchLoadAreaGraphics_Done

  ; Does it use this level's boss graphics set?
  TXA
  LSR
  LSR
  LSR
  LSR
  CMP last_graphics_set
  BNE LoadForcedEnemyGraphicsId

 PatchLoadAreaGraphics_Done:
  RTS


LoadForcedEnemyGraphicsForce:
  LDA force_enemies
  BNE LoadForcedEnemyGraphics_DoOverride

LoadLevelEnemyGraphics:
  LDA #$00
  STA PPU_MASK

  LDA #$01
  LDY current_level
  BEQ LoadForcedEnemyGraphics_Overworld

  LDA #$02
  TAX  ; LDX #$02
  JSR DungeonCopyBufferToPpuFast

  LDY current_level
  LDA dLevelSets,Y
  PHA
  AND #$0F
  LDX #$04
  JSR DungeonCopyBufferToPpuFast

  PLA
  LSR
  LSR
  LSR
  LSR
  LDX #$06
  JMP DungeonCopyBufferToPpuFast


GetGraphicsSourcePointers:
  ASL
  TAY
  LDA dGraphicsSetPointers-2,Y
  STA $00
  LDA dGraphicsSetPointers-1,Y
  STA $01
 GetGraphicsSourcePointers_Done:
  RTS


LoadForcedEnemyGraphicsId:
  LDA force_enemies
  BEQ GetGraphicsSourcePointers_Done

 LoadForcedEnemyGraphics_DoOverride:
  LDY force_enemy_id
  LDA dGraphicsSets,Y
  BEQ GetGraphicsSourcePointers_Done

  STA last_graphics_set

  LDX #$00
  STX PPU_MASK

  CMP #$01
  BNE +

 LoadForcedEnemyGraphics_Overworld:
  ; Load overworld graphics.
  JSR GetGraphicsSourcePointers
  LDA #$07
  STA $02
  LDA #$20
  STA $03
  LDX #$02
  JMP CopyBufferToPpuBank3Fast

 +
  PHA

  ; Load the fixed dungeon sprite graphics.
  LDA #$02
  TAX ; LDX #$02
  JSR DungeonCopyBufferToPpuFast

  PLA
  CMP #$02
  BEQ GetGraphicsSourcePointers_Done

  CMP #$06
  BCS +

  ; Load dungeon enemy graphics.
  LDX #$04
  JMP DungeonCopyBufferToPpuFast

 +
  ; Load dungeon boss graphics.
  LDX #$06
  JMP DungeonCopyBufferToPpuFast


DungeonCopyBufferToPpuFast:
  JSR GetGraphicsSourcePointers
  LDA dDungeonGraphicsSizes,X
  STA <$02
  LDA dDungeonGraphicsSizes+1,X
  STA <$03
  ; Falls through.

; [WIP Copy most of the comment from Bank2's version. Note that it also fetches the destination address.]
CopyBufferToPpuBank3Fast:
  LDA dAreaGraphicsDestinationPpuPointers,X
  STA PPU_ADDRESS
  LDA dAreaGraphicsDestinationPpuPointers+1,X
  STA PPU_ADDRESS
  ; Note that the size in $02-03 is big endian.
  LDY #$00

  ; If there are no hundreds, skip to the partial block.
  LDA $02
  BEQ CopyBufferToPpuBank3_LowPart

 CopyBufferToPpuBank3_CopyLoopHigh:
  ; Copy this block of #$100.
  LDA ($00),Y
  STA PPU_DATA
  INY
  BNE CopyBufferToPpuBank3_CopyLoopHigh

  ; Advance the destination by #$100.
  INC $01

  ; Reduce the remaining size by #$100. If this was the last full #$100, move on to the remaining partial block.
  DEC $02
  BNE CopyBufferToPpuBank3_CopyLoopHigh
  BEQ CopyBufferToPpuBank3_LowPart  ; Unconditional.


 CopyBufferToPpuBank3_CopyLoopLow:
  ; Copy one byte of the partial block.
  LDA ($00),Y
  STA PPU_DATA
  INY

 CopyBufferToPpuBank3_LowPart:
  ; If we haven't finished the partial block, copy the next byte.
  CPY $03
  BNE CopyBufferToPpuBank3_CopyLoopLow

 CopyBufferToPpuBank3_Done:
  RTS


CopyCustomSpriteGraphicsWrapper:
  LDA $00
  PHA
  LDA $01
  PHA
  LDA $02
  PHA
  LDA $03
  PHA

  LDA force_enemies
  BNE +
  STA last_graphics_set
 +

  ; If the enemy uses the same graphics set as the last enemy, we're done.
  LDX force_enemy_id
  LDA dGraphicsSets,X
  CMP last_graphics_set
  BEQ ++

  ; If this enemy uses the common dungeon graphics and the last enemy was a dungeon enemy, we're done.
  CMP #$02
  BNE +
  CMP last_graphics_set
  BCC ++
 +

  TYA
  BNE +
  JSR LoadForcedEnemyGraphicsForce
  JMP ++
 +
  JSR LoadForcedEnemyGraphicsId
 ++

  PLA
  STA $03
  PLA
  STA $02
  PLA
  STA $01
  PLA
  STA $00

  LDA #$02
  JMP SwitchBank


  .IF $ > $BF50
  .ERROR Exceeded free region.
  .ENDIF



.PATCH 04:AAD8

 ObjectAiLanmola_DirectionLoop:
  STA <object_face_direction,X
  STA <$0F
  JSR CheckLanmolaAttemptCounter
  BNE ObjectAiLanmola_DirectionLoop_CheckCollision
 --
  LDA <object_face_direction,X
 -
  LSR
  BCC +
  LDA #$08
 +
  BIT $050F
  BNE ObjectAiLanmola_DirectionLoop
  BEQ -
 ObjectAiLanmola_DirectionLoop_CheckCollision:
  LDY #$F0
  JSR $EE04
  CMP solid_tiles_index
  BCS --
  RTS

  .IF $ != $AAFA
  .ERROR Lanmola patch is incorrect size.
  .ENDIF



.PATCH 04:AB24

; Removes 44 cycles.
; Adds 22 cycles.
; Net 22 gain.
; Saves 9 bytes.
; Spend 9 cycles elsewhere on new code. 13 cycles net now.
; Revert Y handling to spend 4 more cycles. 9 ahead.
; 1 BITs, 3 NOPs would do it.

ObjectAiLanmola_HandleMovement:
  ;Bank4_AB24: A9 A1         LDA #$A1
  ;Bank4_AB26: 85 02         STA <$02
  LDA <object_face_direction,X
  TAY
  AND #$01
  ;Bank4_AB2A: 24 02         BIT <$02
  BEQ +
  LDA <object_pos_x,X
  CLC
  ADC $04E6
  STA <object_pos_x,X
 +

  ;Bank4_AB36: B5 98         LDA <object_face_direction,X
  ;Bank4_AB38: 06 02         ASL <$02
  ;Bank4_AB3A: 24 02         BIT <$02
  TYA
  AND #$02
  SEC
  BEQ +
  LDA <object_pos_x,X
  SBC $04E6
  STA <object_pos_x,X
 +

  ;Bank4_AB45: B5 98         LDA <object_face_direction,X
  ;Bank4_AB47: 06 02         ASL <$02
  ;Bank4_AB49: 24 02         BIT <$02
  TYA
  AND #$04
  CLC
  BEQ +
  LDA <object_pos_y,X
  ADC $04E6
  STA <object_pos_y,X
 +

  ;Bank4_AB54: B5 98         LDA <object_face_direction,X
  ;Bank4_AB56: 06 02         ASL <$02
  ;Bank4_AB58: 24 02         BIT <$02
  TYA
  AND #$08
  SEC
  BEQ +
  LDA <object_pos_y,X
  SBC $04E6
  STA <object_pos_y,X
 +

  ; Jump to new location because there's not enough space for this.
  LDA #$05
  STA lanmola_attempt_counter


  JMP PatchObjectAiLanmola_HandleMovement


  .IF $ > $AB64
  .ERROR Lanmola movement patch is incorrect size.
  .ENDIF



.PATCH 04:AC94

  JSR GanonLightRoom

.PATCH 04:AD0A

  ; Spend 7 cycles on show_ganon when disabled.
  LDA show_ganon
  BEQ +
  JSR $AEB5
 +

  INC $046B,X
  LDA $046B,X
  CMP #$06
  BNE +
  LDA #$00
  STA $046B,X
 +
  LDA #$01
  STA object_subgrid_offset,X

  ; This used to be called indirectly. Call it directly now.
  JSR $9E58

  ; Spend 3 cycles to redirect.
  JMP PatchObjectAiGanon


  .IF $ > $AD2D
  .ERROR Ganon patch is too large.
  .ENDIF



.PATCH 04:B500

PatchObjectAiGanon:
  ; Inline $9E9D to save 12 cycles.
  LDY <object_face_direction,X
  LDA <object_pos_x,X
  CLC
  ADC $9E87,Y
  STA <object_pos_x,X
  LDA <object_pos_y,X
  CLC
  ADC $9E92,Y
  STA <object_pos_y,X

  ; Spend 2 to get reach 12 cycles spent in total (to cancel out 12 saved).
  NOP

  JSR $9E23

  LDA <frame_counter
  AND #$3F
  BNE +
  LDA #$56
  JSR $82AF
 +
  RTS



GanonLightRoom:
  LDA room_light_mode
  JSR UseJumpTable
  .dw $B1D1  ; Updates this to skip the 'Is room dark?' check.
  .dw $B1E4
  .dw $B1DC


 -
  JMP $6FB8
CheckLanmolaAttemptCounter:
  DEC lanmola_attempt_counter
  BNE -

  ; If the lanmola is stuck despite being willing to go in all directions, just pick one at random.
  LDA $050F
  CMP #$0F
  BNE +

  LDA random_lfsr,X
  AND #$03
  TAY
  LDA dBitTable,Y
  STA object_face_direction,X
  PLA
  PLA
  RTS

 +
  ; The lanmola got stuck without all directions available, so make them all available.
  LDA #$05
  STA lanmola_attempt_counter

  LDA #$0F
  STA $050F
  JMP $6FB8


PatchObjectAiLanmola_HandleMovement:
  LDA #$08
  STA $02
  NOP
  NOP
  NOP
  NOP
  RTS


  .IF $ > $BF50
  .ERROR Exceeded free region.
  .ENDIF



.PATCH 05:8125

  JSR SetUpDoorframeSpritesWrapper



.PATCH 05:82CD

  ; Skips most of the HandleDoorScrollType function, which is a vestigial function that misbehaves in dungeons when
  ; scrolling and not in a door.
  JSR $E6B8



.PATCH 05:81E1
  LDY scroll_type
.PATCH 05:8259
  LDY scroll_type
.PATCH 05:8429
  ; Patch the tick frame mode handler for setting up fast scrolling.
  .dw PatchModeScrollStateInit
.PATCH 05:8459
  LDX scroll_type
.PATCH 05:8466
  LDX scroll_type
.PATCH 05:849B
  LDY scroll_type



.PATCH 05:8385
  JSR PatchDarknessFlag
.PATCH 05:87A7
  JSR PatchDarknessFlag



.PATCH 05:8856

  JSR PatchAutowalkDistance



.PATCH 05:88C7

  JSR PatchEnemyLoading
  NOP
  NOP



.PATCH 05:B084

  JSR SetUpDoorframeSpritesWrapper



.PATCH 05:B08A

  JSR PatchSaveKilledEnemies



.PATCH 05:B1D2

  JSR HandleLink



.PATCH 05:B842

  ; Load the item type even if the item is collected.
  LDY current_screen
  LDA current_area_table_4,Y
  AND #$1F
  CMP #$03
  BNE +
  DEC $BF
 +
  STA $AB

  JSR $7314  ; CheckItemCollected
  BNE $B863



.PATCH 05:B900

PatchInitMode05:
  LDA #$00
  STA screen_warp_flags
  LDY time_transitions
  BNE +
  STA secs
  STA frames
 +
  JMP $EA6B

PatchInitMode09:
  LDA #$00
  STA screen_warp_flags
  LDY time_transitions
  BNE +
  STA secs
  STA frames
 +
  JMP InitMode09

PatchInitMode0B:
  LDA #$00
  STA screen_warp_flags
  LDY time_transitions
  BNE +
  STA secs
  STA frames
 +
  JMP InitMode0B

PatchInitMode0C:
  LDA #$00
  STA screen_warp_flags
  LDY time_transitions
  BNE +
  STA secs
  STA frames
 +
  JMP InitMode0C


PatchInitMode06:
  LDA current_state
  BNE +
  LDA time_transitions
  BEQ +
  LDY #$00
  STY secs
  INY
  STY frames
 +
  JMP $B07A

PatchInitMode0A:
  LDA current_state
  BNE +
  LDA time_transitions
  BEQ +
  LDY #$00
  STY secs
  INY
  STY frames
 +
  JMP $B0FC

PatchInitMode10:
  LDA current_state
  BNE +
  LDA time_transitions
  BEQ +
  LDY #$00
  STY secs
  INY
  STY frames
 +
  JMP $8628

PatchInitMode12:
  LDA current_state
  BNE +
  LDA time_transitions
  BEQ +
  LDY #$00
  STY secs
  INY
  STY frames
 +
  JMP $A833


; If settings from an old version need to be cleared or mutated to work with a new format, the signature can be
; changed.
dSramSignature:
  .db $42,$75,$66,$66,$65,$74,$00  ; "Buffet" 00
 dSramSignature_End:

InitializePracticeRam:
  ; Clear out some SRAM space for saved variables.
  LDY #(dSramSignature_End - dSramSignature - 1)
 -
  LDA sram_signature,Y
  CMP dSramSignature,Y
  BNE InitializePracticeRam_ClearSram
  DEY
  BPL -
  BMI InitializePracticeRam_ClearStack  ; Unconditional.

 InitializePracticeRam_ClearSram:
  ; Clear the SRAM region.
  LDA #$00
  LDY #(sram_region_end - sram_region - 1)
 -
  STA sram_region,Y
  DEY
  BPL -

  ; Write the signature.
  LDY #(dSramSignature_End - dSramSignature - 1)
 -
  LDA dSramSignature,Y
  STA sram_signature,Y
  DEY
  BPL -

 InitializePracticeRam_ClearStack:
  ; Clear out the lower stack region.
  LDY #$3F
  LDA #$00
 -
  STA $0100,Y
  DEY
  BPL -

  ; Set the number of enemies to 1 by default.
  LDA #$01
  STA force_enemy_quantity  
  LDA #$00

  ; A must be #$00 when entering Setup.
  JMP Setup


PatchModeScrollStateInit:
  LDA #$00
  LDY scroll_fast
  BNE +
  LDA current_level
 +
  STA scroll_type

  JMP $8439  ; ModeScrollStateInit



PatchEnemyLoading:
  ; If we're not forcing enemies, exit.
  LDA force_enemies
  BEQ PatchEnemyLoading_Done

  ; If this is a passageway, don't force enemies.
  LDA current_mode
  CMP #$09
  BEQ PatchEnemyLoading_Done

  ; If this screen doesn't have enemies, don't force enemies onto it.
  LDY current_screen
  LDA current_area_table_2,Y
  AND #$1F
  BNE +
  LDA current_area_table_3,Y
  BPL PatchEnemyLoading_Done
 +

  ; If we're forcing 0 enemies, handle it in a special way.
  LDA force_enemy_quantity
  BEQ PatchEnemyLoading_ZeroEnemies
  STA $03

  ; Set the enemy or group ID we're forcing.
  LDA force_enemy_id
  STA $02

  ; Bosses and special objects are limited to 1 per screen.
  CMP #$32
  BCC +
  CMP #$62
  BCS +
  LDA #$01
  STA $03
 +

 PatchEnemyLoading_Done:
  LDA $03
 -
  STA num_enemies_loaded

  RTS

 PatchEnemyLoading_ZeroEnemies:
  ; Claim instead that we're spawning 1 enemy of type 0. This prevents the screen from getting marked as having all
  ; enemies killed.
  ; LDA #$00
  STA $02
  LDA #01
  STA $03
  BNE -  ; Unconditional.


PatchSaveKilledEnemies:
  ; If we're warping, we don't want to save kills.
  LDA screen_warp_flags
  BNE +
  JMP $B464

 +
  LDA #$00
  STA link_subgrid_offset
  STA current_state

  INC current_task

  PLA
  PLA
  JMP $B0B6


PatchDarknessFlag:
  LDA screen_warp_flags
  BNE +
  JMP $B68D  ; GetScreenDarknessFlag

 +
  AND #$80
  RTS


PatchAutowalkDistance:
  LDA screen_warp_flags
  BEQ PatchAutowalkDistance_Done

  CPY #$02
  BCS PatchAutowalkDistance_Done  

  LDA link_face_direction
  AND #$0C
  BNE PatchAutowalkDistance_Vertical

  LDA link_pos_y
  CMP #$8D
  BEQ PatchAutowalkDistance_Done
  BNE PatchAutowalkDistance_ForceEject

 PatchAutowalkDistance_Vertical:
  LDA link_pos_x
  CMP #$78
  BEQ PatchAutowalkDistance_Done

 PatchAutowalkDistance_ForceEject:
  LDA $8672+2,Y  ; dAutoWalkEntranceDistance+2
  RTS

 PatchAutowalkDistance_Done:
  LDA $8672,Y  ; dAutoWalkEntranceDistance
  RTS


DoorCloseWrapper:
  LDA #$00
  STA $08

  LDA current_moving_door
  STA $02
  JSR $A3F6  ; GetDoorType
  CMP #$04
  BCC +

  JSR $A6C3
  JSR $A634
 +

  LDA #$02
  JMP SwitchBank


PatchHandlePalette3:
  LDY #$08

  LDA $0350
 -
  CMP $EA62,Y
  BNE +

  LDX $EA59,Y
  BNE ++

 +
  DEY
  BPL -

  LDA $035A
  JMP $EA9D

 ++
  JMP $EAC9


  .IF $ > $BF50
  .ERROR Exceeded free region.
  .ENDIF



.PATCH 06:A06E

  .dw PpuSequenceClearMiniMap

.PATCH 06:A07E

  .dw PpuSequenceClearHudMenu



.IF !dVersionIsPrg1
.PATCH 06:A2D6
.ELSE
.PATCH 06:A361
.ENDIF

  ; HUD attributes.
  .db $00,$00,$00,$00,$00,$00,$00,$00,$04,$00,$00,$44,$55,$11



.PATCH 06:B079

PpuSequenceClearMiniMap:
  .db $20,$62
  .db $48
  .db $24
  .db $20,$82
  .db $48
  .db $24
  .db $20,$A2
  .db $48
  .db $24
  .db $20,$C2
  .db $48
  .db $24
  .db $FF

PpuSequenceClearHudMenu:
  .db $20,$E0
  .db $60
  .db $24
  .db $FF


HidePracticeHud_NoUpdate:
  LDY #67
 -
  DEY
  BNE -
  NOP
  NOP

  JMP DrawPracticeHud_UpdateTime


HidePracticeHud:
  LDA force_update
  BEQ HidePracticeHud_NoUpdate

  LDA #$00
  STA force_update

  ; Ensure we update horizontally, not vertically.
  LDA ppu_control_value
  AND #(~$04)
  STA PPU_CONTROL

  ; Set the address of the start of the practice HUD display.
  LDA #$20
  STA PPU_ADDRESS
  LDA #$42
  STA PPU_ADDRESS

  LDY #28
  LDA #$24
 -
  STA PPU_DATA
  DEY
  BNE -

  LDA #$20
  STA PPU_ADDRESS
  LDA #$D3
  STA PPU_ADDRESS

  LDA #$6A
  STA PPU_DATA

  ; Burn 41 cycles.
  LDY #8
 -
  ; 5 cycles per loop.
  DEY
  BNE -

  JMP DrawPracticeHud_UpdateTime


DrawPassiveHud:
  ; Ensure we update horizontally, not vertically.
  LDA ppu_control_value
  AND #(~$04)
  STA PPU_CONTROL

  ; Set the address of the start of the practice HUD display.
  LDA #$20
  STA PPU_ADDRESS
  LDA #$4D
  STA PPU_ADDRESS
  LDY #$24

  ; Spend 137 cycles.
  LDX #26
 -
  ; 5 cycles per loop.
  DEX
  BNE -
  NOP
  NOP
  NOP

  JMP DrawPracticeHud_DrawCounters


 DrawPracticeHud_NongameplayMode:
  ; Normally, we don't update on non-gameplay frames. However, because state changes during the last gameplay frame, we
  ; need to update one more time after transitioning to another mode. 
  LDY force_update
  BEQ +
  TXA
  STA force_update
  JMP DrawPracticeHud_DoUpdate

 +
  JMP DrawPracticeHud_UpdateTime


HidePracticeHud_Jump:
  JMP HidePracticeHud


DrawPracticeHud:
  ; We assume X == 0.

  ; Only update on gameplay frames.
  LDA current_mode
  CMP #$05
  BEQ +
  CMP #$09
  BCC DrawPracticeHud_NongameplayMode
  CMP #$0D
  BCS DrawPracticeHud_NongameplayMode
 +

  LDY current_task
  BEQ DrawPracticeHud_NongameplayMode

  LDA hide_practice_hud
  BNE HidePracticeHud_Jump

  ; Mark that we need to force an update on the next frame in case it's not a gameplay frame.
  STY force_update

  LDA passive_hud
  BNE DrawPassiveHud

 DrawPracticeHud_DoUpdate:
  ; Ensure we update horizontally, not vertically.
  LDA ppu_control_value
  AND #(~$04)
  STA PPU_CONTROL

  ; Set the address of the start of the practice HUD display.
  LDA #$20
  STA PPU_ADDRESS
  LDA #$42
  STA PPU_ADDRESS

  ; Draw the time.
  LDY secs
  LDA dTensTable,Y
  STA PPU_DATA

  LDA dOnesTable,Y
  STA PPU_DATA

  LDA #$2D  ; "
  STA PPU_DATA
  
  LDY frames
  LDA dTensTable,Y
  STA PPU_DATA

  LDA dOnesTable,Y
  STA PPU_DATA


  LDY #$24
  STY PPU_DATA


  ; Draw clip help. Indicate if Link can clip with buffer-only or both buffer and dpad. If not, draw a blank tile.
  LDA link_speed
  CMP #$60
  BNE DrawPracticeHud_SkipClipHelp_Burn31  ; 9
 ClipHelpPreBranch:

  ; 8
  LDA link_face_direction
  AND #$0A  ; up/left
  BEQ DrawPracticeHud_ClipHelpPositive ; 16

  ; Negative. 15
  ; Check buffer-only position.
  LDA link_subgrid_offset
  CMP #$FF
  BNE +
  LDA link_subpos
  BMI DrawPracticeHud_SkipClipHelp_Burn10  ; >= #$80. 30

  ; 29
  LDA #$3C  ; Sword.
  STA PPU_DATA
  NOP
  NOP
  NOP
  BNE DrawPracticeHud_ClipHelpDone  ; Unconditional. 38+6

 +
  ; 24
  ; Check buffer/dpad position.
  CMP #$FD
  BNE DrawPracticeHud_SkipClipHelp_Burn11  ; 29
  LDA link_subpos
  BMI +
  BPL DrawPracticeHud_SkipClipHelp_Burn3  ; < #$80. 37
 +
  ; 35
  LDA #$3D  ; Checkmark.
  STA PPU_DATA
  BNE DrawPracticeHud_ClipHelpDone  ; Unconditional. 44

 DrawPracticeHud_ClipHelpPositive:
  ; Positive. 16
  ; Check buffer-only position.
  LDA link_subgrid_offset
  CMP #$01
  BNE +  ; 25
  ; 24
  LDA link_subpos
  BPL DrawPracticeHud_SkipClipHelp_Burn9  ; < #$80. 31

  ; 30
  BIT $00
  NOP
  LDA #$3C  ; Sword.
  STA PPU_DATA
  BNE DrawPracticeHud_ClipHelpDone  ; Unconditional. 39+5

 +
  ; Check buffer/dpad position. 25
  CMP #$03
  BNE DrawPracticeHud_SkipClipHelp_Burn10  ; 30
  LDA link_subpos
  BMI DrawPracticeHud_SkipClipHelp_Burn4  ; >= #$80. 36

  ; 35
  LDA #$3D  ; Checkmark.
  STA PPU_DATA
  BNE DrawPracticeHud_ClipHelpDone  ; Unconditional. 44


 DrawPracticeHud_SkipClipHelp_Burn31:
  NOP
  NOP
  NOP
  NOP
  NOP
  NOP
  NOP
  NOP
  NOP
  NOP
 DrawPracticeHud_SkipClipHelp_Burn11:
  NOP
 DrawPracticeHud_SkipClipHelp_Burn9:
  NOP
  NOP
 DrawPracticeHud_SkipClipHelp_Burn5:
  NOP
 DrawPracticeHud_SkipClipHelp_Burn3:
  STY PPU_DATA
  JMP DrawPracticeHud_ClipHelpDone


 DrawPracticeHud_SkipClipHelp_Burn10:
  NOP
  NOP
  NOP
 DrawPracticeHud_SkipClipHelp_Burn4:
  NOP
  NOP
  STY PPU_DATA

 DrawPracticeHud_ClipHelpDone:
  ; 44 cycles.

  .IF >ClipHelpPreBranch != >DrawPracticeHud_ClipHelpDone
  .ERROR Clip help branches cross a page boundary.
  .ENDIF


  ; Draw Link's grid position information.
  LDA link_subgrid_offset
  LSR
  LSR
  LSR
  LSR
  STA PPU_DATA

  LDA link_subgrid_offset
  AND #$0F
  STA PPU_DATA

  LDA #$2C  ; .
  STA PPU_DATA
  
  LDA link_subpos
  LSR
  LSR
  LSR
  LSR
  STA PPU_DATA


 DrawPracticeHud_DrawCounters:
  STY PPU_DATA

  ; Draw the recorder counter. Modify the value to show which dungeon it will take Link to.
  LDX #$35  ; Whirlwind icon.
  STX PPU_DATA
  LDA recorder_destination_counter
  AND #$07
  CLC
  ADC #$01
  STA PPU_DATA

  STY PPU_DATA


  ; Draw the global counter.
  LDX #$31  ; Global icon.
  STX PPU_DATA

  LDA kill_counter
  AND #$0F
  STA PPU_DATA


  ; Draw the streak counter.
  INX  ; LDX #$32  ; Rupee icon.
  LDA drop_forced_bomb
  BNE +
 ForcedBombPreBranch:
  .db $24  ; BIT Zero Page.
 ForcedBombPostBranch:
 +
  INX  ; LDX #$33  ; Bomb icon.
  STX PPU_DATA
  ; 14

  .IF >ForcedBombPreBranch != >ForcedBombPostBranch
  .ERROR Forced bomb branch crosses a page boundary.
  .ENDIF


  LDA ten_count
  AND #$0F
  STA PPU_DATA


  ; Draw the fairy counter.
  LDX #$34  ; Fairy icon.
  STX PPU_DATA

  LDA fairy_counter
  LSR
  LSR
  LSR
  LSR
  STA PPU_DATA

  LDA fairy_counter
  AND #$0F
  STA PPU_DATA

  STY PPU_DATA


  ; Draw the spawn counter.
  LDX #$4C  ; Cloud spawn icon.
  STX PPU_DATA

  LDA spawn_counter
  AND #$0F
  STA PPU_DATA


  ; Draw the edge spawn position.
  INX  ; LDX #$4D  ; Enemy icon.
  STX PPU_DATA

  LDA edge_spawn_position
  LSR
  LSR
  LSR
  LSR
  STA PPU_DATA

  LDA edge_spawn_position
  AND #$0F
  STA PPU_DATA


  ; Draw the bubble countdown timer. Put this on the bottom edge of the A button box.
  LDX #$00

  LDA #$20
  STA PPU_ADDRESS
  LDA #$D3
  STA PPU_ADDRESS

  LDY sword_disable_timer  ; ,X  ; Index with X to burn 1 cycle.
  BEQ +
 BubblePreBranch:
  DEY  ; Adjust it downward so it goes 0-F (fits in one digit).
  JMP ++
  ; Add in padding so we can get meet the timer update branch requirement while aligning earlier branches to not cross
  ; page boundaries.
  .dsb $6F, $00
 BubblePostBranch:
 +
  NOP
  LDY #$6A  ; Bottom box edge.
 ++
  STY PPU_DATA
  ; 15

  .IF >BubblePreBranch != >BubblePostBranch
  .ERROR Bubble timer branch crosses a page boundary.
  .ENDIF


 DrawPracticeHud_UpdateTime:
  ; Clear the address so we execute from the top left of the nametables.
  STX PPU_ADDRESS
  STX PPU_ADDRESS

  ; Update the frames/seconds variables. We do this here so it doesn't eat into vblank time.
  ; X == 0.
  LDA frames
  CLC
  ADC #$01
  CMP #60
  BCC dTimerNewPage  ; Force the branch to cross a page boundary so both paths take 4 cycles.
 dTimerOldPage:
  TXA
 dTimerNewPage:
  STA frames

  LDA secs
  ADC #$00
  CMP #100
  BCC +
  TXA
 +
  BCC +  ; Balance the cycles. The first branch area consumes 3 or 4 cycles, so this consumes 3 or 2 to even it out.
 +
  STA secs
  ; 36 cycles

  .IF >dTimerNewPage == >dTimerOldPage
  .ERROR Branch cycle-manipulation failed because branch does not cross a page boundary.
  .ENDIF


  JMP DrawPracticeHud_Return


; Page-align the tables so indexed loads are always 4 cycles.
.dsb $100 - <$, $00

dOnesTable:
    db $0,$1,$2,$3,$4,$5,$6,$7,$8,$9  ; 0
    db $0,$1,$2,$3,$4,$5,$6,$7,$8,$9  ; 10
    db $0,$1,$2,$3,$4,$5,$6,$7,$8,$9  ; 20
    db $0,$1,$2,$3,$4,$5,$6,$7,$8,$9  ; 30
    db $0,$1,$2,$3,$4,$5,$6,$7,$8,$9  ; 40
    db $0,$1,$2,$3,$4,$5,$6,$7,$8,$9  ; 50
    db $0,$1,$2,$3,$4,$5,$6,$7,$8,$9  ; 60
    db $0,$1,$2,$3,$4,$5,$6,$7,$8,$9  ; 70
    db $0,$1,$2,$3,$4,$5,$6,$7,$8,$9  ; 80
    db $0,$1,$2,$3,$4,$5,$6,$7,$8,$9  ; 90

dTensTable:
    db $0,$0,$0,$0,$0,$0,$0,$0,$0,$0  ; 0
    db $1,$1,$1,$1,$1,$1,$1,$1,$1,$1  ; 10
    db $2,$2,$2,$2,$2,$2,$2,$2,$2,$2  ; 20
    db $3,$3,$3,$3,$3,$3,$3,$3,$3,$3  ; 30
    db $4,$4,$4,$4,$4,$4,$4,$4,$4,$4  ; 40
    db $5,$5,$5,$5,$5,$5,$5,$5,$5,$5  ; 50
    db $6,$6,$6,$6,$6,$6,$6,$6,$6,$6  ; 60
    db $7,$7,$7,$7,$7,$7,$7,$7,$7,$7  ; 70
    db $8,$8,$8,$8,$8,$8,$8,$8,$8,$8  ; 80
    db $9,$9,$9,$9,$9,$9,$9,$9,$9,$9  ; 90


  .IF $ > $BF50
  .ERROR Exceeded free region.
  .ENDIF



.PATCH 07:E440  ; CODE

  ; ====[NmiCounter]====
  Setup:
    ; Expects A == #$00.
    STA has_init_sram

    JSR $B4AC  ; ValidateOrInitializeSram
    JSR $B4E8  ; InitializeRam
    JSR $E45E  ; SetUpAudioAndGraphics

    LDA ppu_control_value
    ORA #$A0  ; kPpuControlEnableVblankNmi | kPpuControl8x16Sprites
    STA PPU_CONTROL
    STA ppu_control_value

    ; Set the NMI counter so the next NMI's increment will clear it.
    LDY #$FF
    STY nmi_counter
   -
    JMP -  ; Wait for NMI.


  .IF $ > $E45E
  .ERROR Setup patch too large.
  .ENDIF
  .IF $ < $E45E
    ; Freed space.
    .dsb $E45E - $, $00  ; BRK.
  .ENDIF



.PATCH 07:E484  ; CODE

    ; This just exists here to make debuggers disassemble the start of this function properly.
    BRK

  ; Changes the frame handler to keep NMIs enabled.
  HandleFrame:
    ; Switch the current vertical nametable, if needed.
    LDX <switch_base_nametable
    BEQ +
    EOR #$02  ; kPpuControlScrollYHigh
    STA <ppu_control_value
   +

    AND #$FE  ; ~kPpuControlScrollXHigh
    LDX PPU_STATUS


  .IF $ != $E492
  .ERROR NmiCounter change is wrong length.
  .ENDIF



.PATCH 07:E4C9

  LDX #$00
  STX PPU_ADDRESS
  JMP DrawPracticeHud
  NOP
  NOP
  NOP
 DrawPracticeHud_Return:



.PATCH 07:E53B

  ; Various optimizations to save time.
    JSR $E62D  ; ReadJoypads

    ; Handle the LFSR.
    ; We use zero page wraparound so we can count up toward 0, avoiding the need for a second counter.
    LDX #$F3  ; #$00 - random array size.

    ; If bits 0 and 8 of the LFSR are the same, use 0 as the new random bit. Otherwise, use 1.
    LDA <random_lfsr
    EOR <random_lfsr+1
    LSR
    LSR

    BCS +  ; Burn a cycle if the bit was 1 to match the original behavior.
   +

    ; Advance the random number sequence by 1 bit.
   -
    ROR <random_lfsr+13,X
    INX
    BNE -
    ; X == 0.

    ; Handle all game sounds.
    TXA  ; LDA #$00

    JSR SwitchBank
    JSR $9825  ; HandleAudio

    ; Advance the frame counter.
    INC <frame_counter

    ; If the current mode has already been initialized, handle it. Otherwise, initialize it.
    LDA <current_task
    BNE +
    JSR $E8F8
    JMP ++
   +
    JSR $EB30
   ++

    ; Reenable the NMI for vblank start and clear the bit indicating vblank has started so that the interrupt won't
    ; immediately fire from stale state.
    LDA <ppu_control_value
    ORA #$80
    STA <ppu_control_value
    LDX PPU_STATUS
    STA PPU_CONTROL

    ; If the performance monitor is enabled, draw it.
    LDY show_lag
    BEQ +
    JMP ShowLag
   +

    ; Burn any spare cycles here. This puts the write to nmi_counter on the same cycle as the write to PPU_CONTROL in
    ; the original, both of which allow new frames to run.
    ; (Currently 0 cycles to burn!)

    ; Allow new frames to run. There is a risk that interrupts can repeatedly land between here and the RTI,
    ; overflowing the stack. This risk also exists in the original game, with about a 4 cycle window. Getting the exact
    ; same timing two frames in a row during gameplay, particularly given that the HUD behaves differently on even and
    ; odd frames, is probably impossible, though this would be more likely in non-gameplay frames.
    DEC nmi_counter
   HandleFrame_EndOfFrame:

    ; Do a 3-cycle dummy instruction to have the same instruction boundaries post-write as the original.
    BIT $00

    ; End the frame.
    RTI

  .IF $ > $E580
  .ERROR HandleFrame too long.
  .ENDIF



.PATCH 07:E92D
  .dw PatchInitMode05
  .dw PatchInitMode06
.PATCH 07:E935
  .dw PatchInitMode09
  .dw PatchInitMode0A
  .dw PatchInitMode0B
  .dw PatchInitMode0C
.PATCH 07:E943
  .dw PatchInitMode10
.PATCH 07:E947
  .dw PatchInitMode12



.PATCH 07:EA1F

  JSR PatchFuncBank7_EA11
  STA current_screen

  .IF $ != $EA24
  .ERROR FuncBank7_EA11 patch incorrect length.
  .ENDIF



.PATCH 07:EA9A

  JMP PatchHandlePalette3



.PATCH 07:EADA

  JSR SetUpDoorframeSpritesWrapper



.PATCH 07:EB44

  .dw HandleModeGameplayTask1

.PATCH 07:EB4C

  .dw HandleModeGameplayTask1
  .dw HandleModeGameplayTask1
  .dw HandleModeGameplayTask1
  .dw HandleModeGameplayTask1



.PATCH 07:EC1C

PatchFuncBank7_EA11:
  ; If we're doing a level and entry screen warp, load the screen and clear the force flag.
  LDX force_entry_screen
  BPL +
  TXA
  AND #$7F
  STA force_entry_screen
 +

  CMP cave_exit_screen
  RTS


 HandleFrame_DoHaltedObjects:
  LDA #$04
  JSR SwitchBank
  JMP $B1BE

 HandleFrame_FinishHandlePause:
  LDA #$05
  JSR SwitchBank
  JSR $B559
  JMP $ED89

 HandleFrame_ContinueBank7:
  ; Inlines HideDynamicSprites to save 12 cycles.

  ; Optimizes loop to saves 80 cycles.
  LDX #$60
  LDA #$F8
 -
  STA $0200,X
  INX
  INX
  INX
  INX
  BNE -

  ; Inlines to save 14 cycles (12 on call and 2 on using X to remove CLC for adding).
  LDX $0342
  INX
  CPX #$28
  BNE +
  LDX #$00
 +
  STX current_sprite_number
  STX $0342

  .IF $ != $EC5B
  .ERROR HandleFrame patch starting at the wrong location.
  .ENDIF



.PATCH 07:EC88

  JSR HandleLink



.PATCH 07:ED86

  JSR ShowTarget



.PATCH 07:ED96

HandleLink:
  LDX #$00
  ; Inlines DecrementObjectIframes and removes X indexing to save 13 cycles.
  LDA link_iframes
  BEQ +
  LDA frame_counter
  LSR
  BCS +
  DEC link_iframes,X  ; Index with X to burn 1 cycle of savings.
 +

  .IF $ != $EDA5
  .ERROR HandleLink patch starting at the wrong location.
  .ENDIF



.PATCH 07:FF43

ShowLag:
  LDA ppu_mask_value
  ORA #$E0  ; kPpuMaskEmphasizeBlue | kPpuMaskEmphasizeGreen | kPpuMaskEmphasizeRed
  STA PPU_MASK

  DEC nmi_counter

  RTI




.PATCH 07:FF90

  ; Switch to the correct bank to save some bytes. This used to swap in bank 7 for no reason.
  LDA #$05
  JSR SwitchBank
  JMP InitializePracticeRam



.PATCH 07:FFC0

NmiWrapper:
  ; If this isn't a lag frame, handle it as normal.
  INC nmi_counter
  BNE +

  LDA ppu_control_value
  JMP HandleFrame

 +
  ; This is a lag frame. We use force_update as a proxy for what mode we're in, because the mode can change early in
  ; the last gameplay frame before lag might happen. Checking the mode directly would make us miss counting the lag
  ; frame.
  PHA
  LDA #$00
  STA nmi_counter

  ;LDA force_update
  ;BEQ NmiWrapper_Done

  ; Count this lag frame.
  LDA frames
  CLC
  ADC #$01
  CMP #60
  BCC +
  LDA #$00
 +
  STA frames
  LDA secs
  ADC #$00
  CMP #100
  BCC +
  LDA #$00
 +
  STA secs

 NmiWrapper_Done:
  PLA
  RTI


SetUpDoorframeSpritesWrapper:
  LDA disable_wall_sprites
  BNE $FFBF
  JMP SetUpDoorframeSprites


  .IF $ > $FFFA || $ < $FFC0
  .ERROR NmiWrapper overflowed.
  .ENDIF



.PATCH 07:FFFA
  .dw NmiWrapper
.PATCH 07:FFFE
  .dw $FF50