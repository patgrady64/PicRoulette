// Converts from ASCII to Zelda characters.

#include <iostream>

int main(int argc, char** argv) {
  if (argc != 2) {
    return 1;
  }

  std::cout << "Converting: " << argv[1] << std::endl;

  std::cout << ".db ";

  for (int i = 0; argv[1][i] != 0; ++i) {
    if (i != 0) {
      std::cout << ",";
    }

    char c = argv[1][i];
    if (c >= 'a' && c <= 'z') {
      c = c - 'a' + 10;
    } else if (c >= 'A' && c <= 'Z') {
      c = c - 'A' + 10;
    } else if (c >= '0' && c <= '9') {
      c = c - '0';
    } else if (c == ' ') {
      c = 0x24;
    } else if (c == ',') {
      c = 0x28;
    } else if (c == '!') {
      c = 0x29;
    } else if (c == '\'') {
      c = 0x2a;
    } else if (c == '&') {
      c = 0x2b;
    } else if (c == '.') {
      c = 0x2c;
    } else if (c == '"') {
      c = 0x2d;
    } else if (c == '?') {
      c = 0x2e;
    } else if (c == '-') {
      c = 0x2f;
    } else {
      std::cout << "\nEncountered unknown character: " << c << " " << +c << std::endl;
      return 1;
    }

    std::cout << "$" << std::hex << +c;
  }

  std::cout << std::endl;

  return 0;
}